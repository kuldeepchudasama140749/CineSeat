/* ==========================================================================
   CineSeat  -  seed.js
   Fills localStorage with demo data the FIRST time the site is opened,
   so the movie pages and the admin dashboard are never empty.
   Runs again only if the admin presses "Reset demo data".
   ========================================================================== */

/* Screens and show timings used by the cinema */
const SCREENS = ['Audi 1', 'Audi 2', 'Audi 3', 'Audi 4'];
const SLOTS   = ['10:15', '13:30', '16:45', '19:00', '22:15'];

/* Seat layout: rows A-J, 12 seats per row.
   A-C = Silver, D-G = Gold, H-J = Recliner  */
const ROWS = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
const COLS = 12;

function seatTier(rowLetter) {
  if ('ABC'.includes(rowLetter)) return 'silver';
  if ('DEFG'.includes(rowLetter)) return 'gold';
  return 'recliner';
}

/* ---- The 12 demo movies ------------------------------------------------- */
const DEMO_MOVIES = [
  { title: 'Jawan', poster: 'jawan', genre: 'Action', language: 'Hindi', format: '2D',
    duration: 169, rating: 8.2, certificate: 'UA', status: 'now',
    synopsis: 'A high-octane thriller about a man driven by a personal vendetta to rectify the wrongs in society, while keeping a promise made years ago.',
    cast: ['Shah Rukh Khan', 'Nayanthara', 'Vijay Sethupathi', 'Deepika Padukone'] },

  { title: 'Oppenheimer', poster: 'oppenheimer', genre: 'Drama', language: 'English', format: 'IMAX',
    duration: 180, rating: 8.9, certificate: 'A', status: 'now',
    synopsis: 'The story of J. Robert Oppenheimer and his role in the development of the atomic bomb, and the moral weight he carried for the rest of his life.',
    cast: ['Cillian Murphy', 'Emily Blunt', 'Robert Downey Jr.', 'Matt Damon'] },

  { title: 'Dune: Part Two', poster: 'dune-two', genre: 'Sci-Fi', language: 'English', format: 'IMAX',
    duration: 166, rating: 8.7, certificate: 'UA', status: 'now',
    synopsis: 'Paul Atreides unites with the Fremen to wage war against House Harkonnen, while torn between the love of his life and the fate of the universe.',
    cast: ['Timothee Chalamet', 'Zendaya', 'Rebecca Ferguson', 'Austin Butler'] },

  { title: '12th Fail', poster: '12th-fail', genre: 'Drama', language: 'Hindi', format: '2D',
    duration: 147, rating: 9.0, certificate: 'U', status: 'now',
    synopsis: 'Based on a true story, a boy from a small village in Chambal restarts his education from scratch and fights every odd to clear one of the toughest exams.',
    cast: ['Vikrant Massey', 'Medha Shankr', 'Anant Joshi', 'Anshumaan Pushkar'] },

  { title: 'Interstellar', poster: 'interstellar', genre: 'Sci-Fi', language: 'English', format: 'IMAX',
    duration: 169, rating: 8.7, certificate: 'UA', status: 'now',
    synopsis: 'With Earth slowly becoming unlivable, a team of explorers travels through a wormhole in search of a new home for humanity.',
    cast: ['Matthew McConaughey', 'Anne Hathaway', 'Jessica Chastain', 'Michael Caine'] },

  { title: 'Stree 2', poster: 'stree-2', genre: 'Horror', language: 'Hindi', format: '2D',
    duration: 149, rating: 7.6, certificate: 'UA', status: 'now',
    synopsis: 'Chanderi is haunted once again, this time by a headless entity that abducts women. The gang must find a way to save their town.',
    cast: ['Rajkummar Rao', 'Shraddha Kapoor', 'Pankaj Tripathi', 'Aparshakti Khurana'] },

  { title: 'Kalki 2898 AD', poster: 'kalki', genre: 'Sci-Fi', language: 'Telugu', format: '3D',
    duration: 181, rating: 7.4, certificate: 'UA', status: 'now',
    synopsis: 'Set in a dystopian future, a bounty hunter searches for a mother whose unborn child may be the prophesied saviour of a dying world.',
    cast: ['Prabhas', 'Deepika Padukone', 'Amitabh Bachchan', 'Kamal Haasan'] },

  { title: 'Laapataa Ladies', poster: 'laapataa', genre: 'Comedy', language: 'Hindi', format: '2D',
    duration: 124, rating: 8.3, certificate: 'U', status: 'now',
    synopsis: 'Two young brides get swapped on a crowded train, setting off a warm and funny journey that quietly says a lot about freedom and choice.',
    cast: ['Nitanshi Goel', 'Pratibha Ranta', 'Sparsh Shrivastava', 'Ravi Kishan'] },

  { title: 'Animal', poster: 'animal', genre: 'Action', language: 'Hindi', format: '2D',
    duration: 201, rating: 6.9, certificate: 'A', status: 'soon', releaseDate: 'Next Friday',
    synopsis: 'A son who idolises his father spirals into violence when the family business comes under attack.',
    cast: ['Ranbir Kapoor', 'Rashmika Mandanna', 'Anil Kapoor', 'Bobby Deol'] },

  { title: 'Fighter', poster: 'fighter', genre: 'Action', language: 'Hindi', format: 'IMAX',
    duration: 166, rating: 7.1, certificate: 'UA', status: 'soon', releaseDate: 'In 2 weeks',
    synopsis: 'The finest air force pilots of the country come together to form a squadron and take on an enemy that is closer than they think.',
    cast: ['Hrithik Roshan', 'Deepika Padukone', 'Anil Kapoor', 'Karan Singh Grover'] },

  { title: 'Singham Again', poster: 'singham', genre: 'Action', language: 'Hindi', format: '2D',
    duration: 144, rating: 6.5, certificate: 'UA', status: 'soon', releaseDate: 'Next month',
    synopsis: 'Bajirao Singham returns with the entire cop universe for one final showdown against his most dangerous enemy yet.',
    cast: ['Ajay Devgn', 'Kareena Kapoor', 'Akshay Kumar', 'Ranveer Singh'] },

  { title: 'Munjya', poster: 'munjya', genre: 'Horror', language: 'Hindi', format: '2D',
    duration: 123, rating: 7.0, certificate: 'UA', status: 'soon', releaseDate: 'Next month',
    synopsis: 'A cursed spirit trapped in a forest for decades latches on to a young man and demands he get married to the girl it loves.',
    cast: ['Sharvari', 'Abhay Verma', 'Mona Singh', 'Sathyaraj'] },
];

/* ---- Demo registered users (password for all of them: Test@123) --------- */
const DEMO_USERS = [
  { name: 'Aarav Sharma',  email: 'aarav@gmail.com',  phone: '9825012345', password: 'Test@123' },
  { name: 'Diya Patel',    email: 'diya@gmail.com',   phone: '9876501234', password: 'Test@123' },
  { name: 'Rohan Mehta',   email: 'rohan@gmail.com',  phone: '9712345678', password: 'Test@123' },
  { name: 'Isha Verma',    email: 'isha@gmail.com',   phone: '9099887766', password: 'Test@123' },
  { name: 'Kabir Nair',    email: 'kabir@gmail.com',  phone: '8866554433', password: 'Test@123' },
  { name: 'Ananya Joshi',  email: 'ananya@gmail.com', phone: '7778889990', password: 'Test@123' }
];

/* --------------------------------------------------------------------------
   Helpers used while building the demo data
   -------------------------------------------------------------------------- */

/* Give a date that is "offset" days away from today, as "YYYY-MM-DD" */
function dateFromToday(offset) {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return d.getFullYear() + '-' + mm + '-' + dd;
}

function randomInt(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
function pickOne(list)       { return list[Math.floor(Math.random() * list.length)]; }

/* Every seat label of the hall, e.g. ["A1", "A2", ... "J12"] */
function allSeatLabels() {
  const seats = [];
  ROWS.forEach(r => { for (let c = 1; c <= COLS; c++) seats.push(r + c); });
  return seats;
}

/* Pick a random set of seats that are "already sold" for a show */
function randomSoldSeats(count) {
  const pool = allSeatLabels();
  const sold = [];
  while (sold.length < count && pool.length) {
    sold.push(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]);
  }
  return sold;
}

/* --------------------------------------------------------------------------
   Build everything
   -------------------------------------------------------------------------- */
function buildDemoData() {
  const settings = getSettings();

  /* ---- 1. Movies ---- */
  const movies = DEMO_MOVIES.map(m => Object.assign({}, m, {
    id: makeId('mv'),
    poster: 'assets/img/posters/' + m.poster + '.svg',
    cast: m.cast.slice()
  }));
  saveMovies(movies);

  /* ---- 2. Shows : 2 shows a day for every "now showing" movie,
          from 2 days ago (history for the admin chart) to 4 days ahead ---- */
  const nowShowing = movies.filter(m => m.status === 'now');
  const shows = [];

  for (let day = -2; day <= 4; day++) {
    const date = dateFromToday(day);

    nowShowing.forEach((movie, i) => {
      const screen = SCREENS[i % SCREENS.length];
      const mySlots = [SLOTS[i % SLOTS.length], SLOTS[(i + 2) % SLOTS.length]];

      mySlots.forEach(time => {
        /* evening shows cost a bit more, like a real multiplex */
        const evening = Number(time.split(':')[0]) >= 17;
        const bump = evening ? 1.2 : 1;

        shows.push({
          id: makeId('sh'),
          movieId: movie.id,
          screen: screen,
          date: date,
          time: time,
          price: {
            silver:   Math.round(settings.price.silver   * bump),
            gold:     Math.round(settings.price.gold     * bump),
            recliner: Math.round(settings.price.recliner * bump)
          },
          /* seats sold before our demo bookings: 20% to 55% of the hall */
          preBooked: randomSoldSeats(randomInt(24, 66))
        });
      });
    });
  }
  saveShows(shows);

  /* ---- 3. Users ---- */
  const users = DEMO_USERS.map(u => Object.assign({}, u, {
    id: makeId('us'),
    joinedAt: new Date(Date.now() - randomInt(5, 200) * 86400000).toISOString(),
    blocked: false
  }));
  saveUsers(users);

  /* ---- 4. Bookings : 18 demo bookings spread over the last 7 days ---- */
  const bookings = [];

  for (let i = 0; i < 18; i++) {
    const show  = pickOne(shows);
    const user  = pickOne(users);
    const movie = movies.find(m => m.id === show.movieId);

    /* choose 1-4 free seats for this booking */
    const free = allSeatLabels().filter(s => !show.preBooked.includes(s));
    const seats = [];
    const howMany = randomInt(1, 4);
    while (seats.length < howMany && free.length) {
      seats.push(free.splice(Math.floor(Math.random() * free.length), 1)[0]);
    }
    if (!seats.length) continue;

    const ticketTotal = seats.reduce((sum, s) => sum + show.price[seatTier(s[0])], 0);

    bookings.push({
      id: 'CS-' + (10000 + i * 977 + randomInt(10, 99)),
      userId: user.id,
      userName: user.name,
      userEmail: user.email,
      showId: show.id,
      movieId: show.movieId,
      movieTitle: movie ? movie.title : 'Movie',
      screen: show.screen,
      date: show.date,
      time: show.time,
      seats: seats,
      snacks: 0,
      fee: settings.convenienceFee * seats.length,
      amount: ticketTotal + settings.convenienceFee * seats.length,
      status: i % 9 === 0 ? 'cancelled' : 'confirmed',
      bookedAt: new Date(Date.now() - randomInt(0, 6) * 86400000 - randomInt(0, 20) * 3600000).toISOString()
    });
  }
  saveBookings(bookings);

  /* ---- 5. Settings ---- */
  saveSettings(settings);
  dbSet(KEYS.seeded, true);
}

/* Run once. If the data was never created, create it now. */
function seedIfNeeded() {
  if (!dbGet(KEYS.seeded, false) || getMovies().length === 0) {
    buildDemoData();
  }
}

/* Used by the "Reset demo data" button on the admin settings page. */
function resetDemoData() {
  Object.values(KEYS).forEach(k => {
    if (k !== KEYS.theme) localStorage.removeItem(k);
  });
  buildDemoData();
}

seedIfNeeded();
