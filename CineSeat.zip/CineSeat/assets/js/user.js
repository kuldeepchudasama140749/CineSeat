/* ==========================================================================
   CineSeat  -  user.js
   All the behaviour of the customer pages. Each page has its own small
   init function, and at the bottom we only run the ones that belong
   to the page that is currently open.
   ========================================================================== */

const PENDING_KEY = 'cs_pending';       /* seats chosen, waiting for payment */
const LAST_KEY    = 'cs_last_booking';  /* id of the booking just completed  */

/* --------------------------------------------------------------------------
   SHARED PIECES
   -------------------------------------------------------------------------- */

/* One movie card, used on the home page and the movies page */
function movieCard(m) {
  const soon = m.status === 'soon';
  return `
    <article class="movie-card ${soon ? 'movie-card--soon' : ''}">
      <a class="movie-card__poster" href="movie-details.html?id=${m.id}">
        <img src="${m.poster}" alt="${esc(m.title)} poster" loading="lazy">
        <span class="movie-card__rating"><i>★</i> ${m.rating}</span>
        <span class="movie-card__fmt">${esc(m.format)}</span>
        <span class="movie-card__hover">
          <span class="btn btn--primary btn--sm">${soon ? 'View details' : 'Book now'}</span>
        </span>
      </a>
      <div class="movie-card__body">
        <h3>${esc(m.title)}</h3>
        <p class="text-xs text-muted">${esc(m.genre)} · ${esc(m.language)} · ${prettyDuration(m.duration)}</p>
      </div>
    </article>`;
}

/* The eye button that shows / hides a password */
function bindPasswordToggles() {
  document.querySelectorAll('.pw-toggle').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const input = document.getElementById(btn.getAttribute('data-pw'));
      if (!input) return;
      const showing = input.type === 'text';
      input.type = showing ? 'password' : 'text';
      btn.textContent = showing ? '👁️' : '🙈';
    });
  });
}

/* Attach live checking (blur + typing) without touching the submit event */
function liveCheck(form, fields) {
  Object.keys(fields).forEach(function (id) {
    const input = form.querySelector('#' + id);
    if (!input) return;
    input.addEventListener('blur',  function () { checkField(input, fields[id]); });
    input.addEventListener('input', function () {
      if (input.classList.contains('is-invalid')) checkField(input, fields[id]);
    });
    if (input.type === 'checkbox') {
      input.addEventListener('change', function () { checkField(input, fields[id]); });
    }
  });
}

/* Which price tier does a seat belong to? "F5" -> "gold" */
function tierOf(seat) {
  const row = seat[0];
  if ('ABC'.indexOf(row) > -1)  return 'silver';
  if ('DEFG'.indexOf(row) > -1) return 'gold';
  return 'recliner';
}

/* --------------------------------------------------------------------------
   HOME PAGE
   -------------------------------------------------------------------------- */
function initHome() {
  const nowShowing = getNowShowing();
  const soon = getComingSoon();

  document.getElementById('nowShowingGrid').innerHTML = nowShowing.map(movieCard).join('');
  document.getElementById('comingSoonRow').innerHTML  = soon.map(movieCard).join('');

  document.getElementById('statMovies').textContent = nowShowing.length;
  document.getElementById('statShows').textContent  =
    getShows().filter(s => s.date >= todayISO()).length;

  /* the hero search box simply carries the words over to the movies page */
  const form = document.getElementById('heroSearch');
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    const q = document.getElementById('heroSearchInput').value.trim();
    window.location.href = 'movies.html' + (q ? '?q=' + encodeURIComponent(q) : '');
  });
}

/* --------------------------------------------------------------------------
   MOVIES PAGE  (search + filters + sorting)
   -------------------------------------------------------------------------- */
function initMoviesPage() {
  const grid      = document.getElementById('movieGrid');
  const noResults = document.getElementById('noResults');
  const countText = document.getElementById('resultCount');
  const chipsBox  = document.getElementById('genreChips');

  const searchInput  = document.getElementById('searchInput');
  const langFilter   = document.getElementById('langFilter');
  const statusFilter = document.getElementById('statusFilter');
  const sortSelect   = document.getElementById('sortSelect');

  let activeGenre = 'all';

  /* if we arrived from the home page search, fill the box */
  const q = urlParam('q');
  if (q) searchInput.value = q;

  /* build the genre chips from the movies we actually have */
  const genres = ['all'];
  getMovies().forEach(m => { if (!genres.includes(m.genre)) genres.push(m.genre); });

  chipsBox.innerHTML = genres.map(g =>
    `<button class="chip ${g === 'all' ? 'is-active' : ''}" data-genre="${g}">${g === 'all' ? 'All genres' : g}</button>`
  ).join('');

  chipsBox.addEventListener('click', function (e) {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    activeGenre = chip.getAttribute('data-genre');
    chipsBox.querySelectorAll('.chip').forEach(c => c.classList.remove('is-active'));
    chip.classList.add('is-active');
    render();
  });

  function render() {
    const words = searchInput.value.trim().toLowerCase();
    let list = getMovies();

    /* 1. search in the title and in the cast list */
    if (words) {
      list = list.filter(m =>
        m.title.toLowerCase().includes(words) ||
        m.cast.join(' ').toLowerCase().includes(words) ||
        m.genre.toLowerCase().includes(words)
      );
    }
    /* 2. dropdown filters */
    if (langFilter.value   !== 'all') list = list.filter(m => m.language === langFilter.value);
    if (statusFilter.value !== 'all') list = list.filter(m => m.status === statusFilter.value);
    if (activeGenre        !== 'all') list = list.filter(m => m.genre === activeGenre);

    /* 3. sorting */
    if (sortSelect.value === 'rating')   list.sort((a, b) => b.rating - a.rating);
    if (sortSelect.value === 'title')    list.sort((a, b) => a.title.localeCompare(b.title));
    if (sortSelect.value === 'duration') list.sort((a, b) => a.duration - b.duration);

    grid.innerHTML = list.map(movieCard).join('');
    countText.textContent = list.length + (list.length === 1 ? ' movie found' : ' movies found');
    noResults.classList.toggle('hidden', list.length > 0);
    countText.classList.toggle('hidden', list.length === 0);
  }

  searchInput.addEventListener('input', render);
  langFilter.addEventListener('change', render);
  statusFilter.addEventListener('change', render);
  sortSelect.addEventListener('change', render);

  document.getElementById('clearFilters').addEventListener('click', function () {
    searchInput.value = '';
    langFilter.value = 'all';
    statusFilter.value = 'all';
    sortSelect.value = 'rating';
    activeGenre = 'all';
    chipsBox.querySelectorAll('.chip').forEach((c, i) => c.classList.toggle('is-active', i === 0));
    render();
  });

  render();
}

/* --------------------------------------------------------------------------
   MOVIE DETAILS PAGE
   -------------------------------------------------------------------------- */
function initDetailsPage() {
  const wrap  = document.getElementById('detailWrap');
  const movie = getMovieById(urlParam('id'));

  if (!movie) {
    wrap.innerHTML = `
      <div class="empty">
        <div class="empty__icon">🎬</div>
        <h3>Movie not found</h3>
        <p>The movie you are looking for is not in our list any more.</p>
        <a class="btn btn--primary mt-4" href="movies.html">Back to all movies</a>
      </div>`;
    return;
  }

  document.title = movie.title + ' | CineSeat';
  document.getElementById('crumbTitle').textContent = movie.title;

  const castHtml = movie.cast.map(function (person) {
    const initials = person.split(' ').map(w => w[0]).slice(0, 2).join('');
    return `<div class="cast"><div class="cast__face">${esc(initials)}</div>${esc(person)}</div>`;
  }).join('');

  wrap.innerHTML = `
    <section class="detail-hero" style="--bg-image:url('${movie.poster}')">
      <div class="detail-hero__inner">
        <img class="detail-hero__poster" src="${movie.poster}" alt="${esc(movie.title)} poster">

        <div>
          <span class="eyebrow">${movie.status === 'now' ? 'Now showing' : 'Coming soon'}</span>
          <h1>${esc(movie.title)}</h1>

          <div class="meta-row">
            <span class="rating-pill"><i>★</i> ${movie.rating} <span class="text-muted text-sm">/ 10</span></span>
            <span class="badge">${esc(movie.certificate)}</span>
            <span class="badge">${esc(movie.format)}</span>
            <span class="badge">${esc(movie.language)}</span>
            <span class="badge">${esc(movie.genre)}</span>
            <span class="badge">${prettyDuration(movie.duration)}</span>
          </div>

          <p>${esc(movie.synopsis)}</p>

          <h4 class="mt-6 mb-4">Cast</h4>
          <div class="cast-row">${castHtml}</div>

          ${movie.status === 'now'
            ? `<a class="btn btn--primary btn--lg mt-6" href="#showtimes">Book tickets →</a>`
            : `<div class="mt-6"><span class="badge badge--warn">Releasing ${esc(movie.releaseDate || 'soon')}</span>
               <p class="text-sm mt-3">Booking opens a few days before release. Keep an eye on this page!</p></div>`}
        </div>
      </div>
    </section>

    <section id="showtimes">
      <div class="section-head">
        <div><span class="eyebrow">Pick a slot</span><h2>Showtimes</h2></div>
      </div>
      <div class="date-strip mb-6" id="dateStrip"></div>
      <div id="showList"></div>
    </section>`;

  if (movie.status !== 'now') {
    document.getElementById('showtimes').innerHTML = `
      <div class="empty">
        <div class="empty__icon">🍿</div>
        <h3>Booking not open yet</h3>
        <p>Shows for this movie will be added closer to the release date.</p>
      </div>`;
    return;
  }

  /* ---- date strip + showtimes ---- */
  const shows = getShowsByMovie(movie.id).filter(s => s.date >= todayISO());
  const dates = [];
  shows.forEach(s => { if (!dates.includes(s.date)) dates.push(s.date); });
  dates.sort();

  const strip    = document.getElementById('dateStrip');
  const showList = document.getElementById('showList');

  strip.innerHTML = dates.map(function (d, i) {
    const dt = new Date(d + 'T00:00:00');
    return `
      <button class="date-pill ${i === 0 ? 'is-active' : ''}" data-date="${d}">
        <span>${dt.toLocaleDateString('en-IN', { weekday: 'short' })}</span>
        <strong>${dt.getDate()}</strong>
        <span>${dt.toLocaleDateString('en-IN', { month: 'short' })}</span>
      </button>`;
  }).join('');

  function renderShows(date) {
    const todays = shows.filter(s => s.date === date);

    if (!todays.length) {
      showList.innerHTML = `<div class="empty"><div class="empty__icon">🎟️</div><h3>No shows on this day</h3><p>Please pick another date.</p></div>`;
      return;
    }

    /* group the shows by screen name */
    const screens = [];
    todays.forEach(s => { if (!screens.includes(s.screen)) screens.push(s.screen); });
    screens.sort();

    showList.innerHTML = screens.map(function (screen) {
      const list = todays.filter(s => s.screen === screen).sort((a, b) => a.time.localeCompare(b.time));

      const buttons = list.map(function (s) {
        const sold = getOccupiedSeats(s.id).length;
        const filling = sold > 72;                       /* 120 seats in a hall */
        return `
          <a class="time-btn ${filling ? 'is-filling' : ''}" href="seats.html?show=${s.id}">
            ${prettyTime(s.time)}
            <small>${filling ? 'Filling fast' : 'Available'}</small>
          </a>`;
      }).join('');

      return `
        <div class="screen-block">
          <div class="screen-block__head">
            <div>
              <strong>${esc(screen)}</strong>
              <div class="text-xs text-muted">${esc(movie.format)} · Dolby Atmos · ₹${list[0].price.silver} onwards</div>
            </div>
            <span class="badge badge--success">${list.length} show${list.length > 1 ? 's' : ''}</span>
          </div>
          <div class="time-grid">${buttons}</div>
        </div>`;
    }).join('');
  }

  strip.addEventListener('click', function (e) {
    const pill = e.target.closest('.date-pill');
    if (!pill) return;
    strip.querySelectorAll('.date-pill').forEach(p => p.classList.remove('is-active'));
    pill.classList.add('is-active');
    renderShows(pill.getAttribute('data-date'));
  });

  if (dates.length) renderShows(dates[0]);
  else showList.innerHTML = `<div class="empty"><div class="empty__icon">🎟️</div><h3>No shows scheduled</h3><p>The admin has not added shows for this movie yet.</p></div>`;
}

/* --------------------------------------------------------------------------
   SEAT SELECTION PAGE
   -------------------------------------------------------------------------- */
function initSeatsPage() {
  if (!requireUser()) return;

  const show = getShowById(urlParam('show'));
  if (!show) { window.location.href = 'movies.html'; return; }

  const movie    = getMovieById(show.movieId);
  const occupied = getOccupiedSeats(show.id);
  const selected = [];

  const MAX_SEATS = 10;
  const ROW_LIST  = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];
  const COLUMNS   = 12;

  /* ---- header ---- */
  document.getElementById('showHead').innerHTML = `
    <div class="card row-between">
      <div class="row">
        <img src="${movie.poster}" alt="" style="width:54px;border-radius:10px">
        <div>
          <h3>${esc(movie.title)}</h3>
          <p class="text-sm text-muted">${esc(movie.certificate)} · ${esc(movie.language)} · ${esc(movie.format)}</p>
        </div>
      </div>
      <div class="text-sm" style="text-align:right">
        <strong>${esc(show.screen)}</strong><br>
        <span class="text-muted">${prettyDate(show.date)} · ${prettyTime(show.time)}</span>
      </div>
    </div>`;

  /* ---- draw the seats ---- */
  const area = document.getElementById('seatArea');
  const tiers = [
    { name: 'Silver',   rows: ['A', 'B', 'C'],           price: show.price.silver },
    { name: 'Gold',     rows: ['D', 'E', 'F', 'G'],      price: show.price.gold },
    { name: 'Recliner', rows: ['H', 'I', 'J'],           price: show.price.recliner }
  ];

  area.innerHTML = tiers.map(function (tier) {
    const rows = tier.rows.map(function (row) {
      let seats = '';
      for (let c = 1; c <= COLUMNS; c++) {
        /* leave a walking aisle after seat 3 and seat 9 */
        if (c === 4 || c === 10) seats += '<span class="seat-gap"></span>';

        const label = row + c;
        const taken = occupied.includes(label);
        seats += `<button type="button"
                    class="seat ${tier.name === 'Recliner' ? 'seat--recliner' : ''} ${taken ? 'is-taken' : ''}"
                    data-seat="${label}" ${taken ? 'disabled aria-label="Seat ' + label + ' is sold"' : 'aria-label="Seat ' + label + '"'}>
                    ${c}
                  </button>`;
      }
      return `<div class="seat-row"><span class="seat-row__letter">${row}</span>${seats}</div>`;
    }).join('');

    return `<div class="tier-label">${tier.name} &nbsp;·&nbsp; ${money(tier.price)}</div>${rows}`;
  }).join('');

  /* ---- clicking a seat ---- */
  area.addEventListener('click', function (e) {
    const seatBtn = e.target.closest('.seat');
    if (!seatBtn || seatBtn.classList.contains('is-taken')) return;

    const label = seatBtn.getAttribute('data-seat');
    const at = selected.indexOf(label);

    if (at > -1) {
      selected.splice(at, 1);
      seatBtn.classList.remove('is-selected');
    } else {
      if (selected.length >= MAX_SEATS) {
        toast('You can select at most ' + MAX_SEATS + ' seats', 'warn');
        return;
      }
      selected.push(label);
      seatBtn.classList.add('is-selected');
    }
    drawSummary();
  });

  /* ---- the price box on the right ---- */
  function drawSummary() {
    const box  = document.getElementById('summaryBox');
    const fee  = getSettings().convenienceFee * selected.length;
    const cost = selected.reduce((sum, s) => sum + show.price[tierOf(s)], 0);

    box.innerHTML = `
      <div class="summary__movie">
        <img src="${movie.poster}" alt="">
        <div>
          <strong>${esc(movie.title)}</strong>
          <div class="text-xs text-muted">${esc(show.screen)}<br>${prettyDate(show.date)} · ${prettyTime(show.time)}</div>
        </div>
      </div>

      <div class="mt-4">
        <div class="summary__line"><span>Seats selected</span><span>${selected.length}</span></div>
        ${selected.length
          ? `<div class="seat-tags">${selected.sort().map(s => `<span class="seat-tag">${s}</span>`).join('')}</div>`
          : `<p class="text-sm text-muted">Tap the seats you want on the map.</p>`}
      </div>

      <div class="mt-4">
        <div class="summary__line"><span>Ticket price</span><span>${money(cost)}</span></div>
        <div class="summary__line"><span>Convenience fee</span><span>${money(fee)}</span></div>
      </div>

      <div class="summary__total"><span>Total</span><strong>${money(cost + fee)}</strong></div>

      <button class="btn btn--primary btn--block btn--lg mt-4" id="proceedBtn" ${selected.length ? '' : 'disabled'}>
        ${selected.length ? 'Proceed to pay' : 'Select seats to continue'}
      </button>`;

    const btn = document.getElementById('proceedBtn');
    if (btn) btn.addEventListener('click', proceed);
  }

  /* ---- save the choice and move to checkout ---- */
  function proceed() {
    if (!selected.length) return;

    /* somebody may have booked these seats in another tab - check again */
    const freshTaken = getOccupiedSeats(show.id);
    const clash = selected.filter(s => freshTaken.includes(s));
    if (clash.length) {
      toast('Seat ' + clash[0] + ' was just sold. Please pick another.', 'error');
      window.location.reload();
      return;
    }

    dbSet(PENDING_KEY, {
      showId: show.id,
      movieId: movie.id,
      seats: selected.slice().sort(),
      createdAt: new Date().toISOString()
    });
    window.location.href = 'checkout.html';
  }

  drawSummary();
}

/* --------------------------------------------------------------------------
   CHECKOUT PAGE
   -------------------------------------------------------------------------- */
function initCheckoutPage() {
  if (!requireUser()) return;

  const pending = dbGet(PENDING_KEY, null);
  if (!pending) { toast('Please choose your seats first', 'warn'); window.location.href = 'movies.html'; return; }

  const show     = getShowById(pending.showId);
  const movie    = getMovieById(pending.movieId);
  const settings = getSettings();
  if (!show || !movie) { window.location.href = 'movies.html'; return; }

  const seats  = pending.seats;
  let snacks   = [];          /* [{name, price, qty}] */
  let discount = 0;
  let coupon   = '';
  let method   = 'card';

  const ticketTotal = seats.reduce((sum, s) => sum + show.price[tierOf(s)], 0);
  const feeTotal    = settings.convenienceFee * seats.length;

  /* ---- booking summary card ---- */
  document.getElementById('orderCard').innerHTML = `
    <div class="row-between mb-4">
      <h3>Your booking</h3>
      <a class="btn btn--ghost btn--sm" href="seats.html?show=${show.id}">Change seats</a>
    </div>
    <div class="row" style="align-items:flex-start;gap:18px">
      <img src="${movie.poster}" alt="" style="width:88px;border-radius:12px">
      <div class="grow">
        <h4>${esc(movie.title)}</h4>
        <p class="text-sm text-muted">${esc(movie.certificate)} · ${esc(movie.language)} · ${esc(movie.format)}</p>
        <div class="ticket__grid" style="margin-top:14px;padding-top:14px">
          <div><span>Screen</span><strong>${esc(show.screen)}</strong></div>
          <div><span>Date</span><strong>${prettyDate(show.date)}</strong></div>
          <div><span>Time</span><strong>${prettyTime(show.time)}</strong></div>
          <div><span>Seats</span><strong>${seats.join(', ')}</strong></div>
        </div>
      </div>
    </div>`;

  /* ---- snack counters ---- */
  document.getElementById('snackList').addEventListener('click', function (e) {
    const btn = e.target.closest('[data-step]');
    if (!btn) return;

    const row   = btn.closest('.snack');
    const out   = row.querySelector('output');
    const price = Number(row.getAttribute('data-price'));
    const name  = row.getAttribute('data-snack');

    let qty = Number(out.textContent) + Number(btn.getAttribute('data-step'));
    if (qty < 0) qty = 0;
    if (qty > 9) { toast('Maximum 9 of one item', 'warn'); qty = 9; }
    out.textContent = qty;

    snacks = snacks.filter(s => s.name !== name);
    if (qty > 0) snacks.push({ name: name, price: price, qty: qty });

    drawBill();
  });

  /* ---- the bill on the right ---- */
  function snackTotal() { return snacks.reduce((sum, s) => sum + s.price * s.qty, 0); }
  function grandTotal() { return ticketTotal + snackTotal() + feeTotal - discount; }

  function drawBill() {
    const box = document.getElementById('billBox');

    box.innerHTML = `
      <h3 class="mb-4">Price details</h3>

      <div class="summary__line"><span>Tickets (${seats.length})</span><span>${money(ticketTotal)}</span></div>
      ${snacks.map(s => `<div class="summary__line"><span>${esc(s.name)} × ${s.qty}</span><span>${money(s.price * s.qty)}</span></div>`).join('')}
      <div class="summary__line"><span>Convenience fee</span><span>${money(feeTotal)}</span></div>
      ${discount ? `<div class="summary__line" style="color:var(--success)"><span>Discount (${esc(coupon)})</span><span>− ${money(discount)}</span></div>` : ''}

      <div class="summary__total"><span>Amount payable</span><strong>${money(grandTotal())}</strong></div>

      <div class="field mt-6" style="margin-bottom:0">
        <label class="label" for="couponInput">Have a coupon?</label>
        <div class="row" style="flex-wrap:nowrap;gap:8px">
          <input class="input" type="text" id="couponInput" placeholder="CINE20" value="${esc(coupon)}" style="text-transform:uppercase">
          <button class="btn btn--soft" type="button" id="applyCoupon">Apply</button>
        </div>
        <small class="error-msg"></small>
        <div class="hint">Try <strong>CINE20</strong> or <strong>FIRST100</strong></div>
      </div>`;

    document.getElementById('applyCoupon').addEventListener('click', applyCoupon);
  }

  /* ---- coupon check (this is validation too) ---- */
  function applyCoupon() {
    const input = document.getElementById('couponInput');
    const code  = input.value.trim().toUpperCase();

    if (!code) { showError(input, 'Please type a coupon code'); return; }

    if (code === 'CINE20') {
      discount = Math.round(ticketTotal * 0.20);
      coupon = code;
      clearError(input);
      toast('Coupon applied — 20% off your tickets!', 'success');
    } else if (code === 'FIRST100') {
      if (getBookingsByUser(currentUser().id).length > 0) {
        showError(input, 'FIRST100 works only on your very first booking');
        discount = 0; coupon = '';
        return;
      }
      discount = Math.min(100, ticketTotal);
      coupon = code;
      clearError(input);
      toast('Coupon applied — ₹100 off!', 'success');
    } else {
      discount = 0; coupon = '';
      showError(input, 'This coupon code is not valid');
      return;
    }
    drawBill();
  }

  /* ---- payment method tabs ---- */
  const tabs = document.getElementById('payTabs');
  tabs.addEventListener('click', function (e) {
    const tab = e.target.closest('.pay-tab');
    if (!tab) return;

    method = tab.getAttribute('data-pay');
    tabs.querySelectorAll('.pay-tab').forEach(t => t.classList.remove('is-active'));
    tab.classList.add('is-active');

    document.querySelectorAll('.pay-panel').forEach(function (panel) {
      panel.classList.toggle('is-active', panel.getAttribute('data-panel') === method);
    });
  });

  /* ---- helpers that make typing easier ---- */
  const form = document.getElementById('payForm');
  formatCardInput(document.getElementById('cardNumber'));
  formatExpiryInput(document.getElementById('cardExpiry'));
  digitsOnly(document.getElementById('cardCvv'), 3);
  digitsOnly(document.getElementById('walletPhone'), 10);
  digitsOnly(document.getElementById('walletOtp'), 6);

  /* ---- the validation rules for each payment method ---- */
  const cardRules = {
    cardName:   [Rule.required('Enter the name printed on the card'), Rule.pattern(RX.name, 'Use letters only, at least 3 characters')],
    cardNumber: [Rule.required('Enter your card number'),
                 Rule.custom(v => v.replace(/\s/g, '').length === 16, 'A card number has 16 digits'),
                 Rule.custom(v => luhnCheck(v), 'This card number is not valid')],
    cardExpiry: [Rule.required('Enter the expiry date'),
                 Rule.pattern(RX.expiry, 'Use the MM/YY format, e.g. 09/29'),
                 Rule.custom(v => expiryIsFuture(v), 'This card has already expired')],
    cardCvv:    [Rule.required('Enter the CVV'), Rule.pattern(RX.cvv, 'The CVV is 3 digits')]
  };
  const upiRules = {
    upiId: [Rule.required('Enter your UPI ID'), Rule.pattern(RX.upi, 'A UPI ID looks like name@bank')]
  };
  const walletRules = {
    walletPhone: [Rule.required('Enter your mobile number'), Rule.pattern(RX.phone, 'Enter a valid 10 digit mobile number')],
    walletOtp:   [Rule.required('Enter the OTP'), Rule.pattern(/^[0-9]{6}$/, 'The OTP is 6 digits')]
  };
  const agreeRule = { agreeTerms: [Rule.checked('Please accept the terms before paying')] };

  liveCheck(form, Object.assign({}, cardRules, upiRules, walletRules, agreeRule));

  /* ---- pay ---- */
  form.addEventListener('submit', function (e) {
    e.preventDefault();

    const active = method === 'card' ? cardRules : (method === 'upi' ? upiRules : walletRules);
    if (!checkForm(form, Object.assign({}, active, agreeRule))) {
      toast('Please fix the highlighted fields', 'error');
      return;
    }

    /* final seat check before we take the money */
    const takenNow = getOccupiedSeats(show.id);
    const clash = seats.filter(s => takenNow.includes(s));
    if (clash.length) {
      toast('Seat ' + clash[0] + ' was just booked by someone else', 'error');
      setTimeout(() => window.location.href = 'seats.html?show=' + show.id, 1200);
      return;
    }

    const btn = document.getElementById('payBtn');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Processing payment...';

    const user = currentUser();

    setTimeout(function () {
      const booking = addBooking({
        userId: user.id,
        userName: user.name,
        userEmail: user.email,
        showId: show.id,
        movieId: movie.id,
        movieTitle: movie.title,
        screen: show.screen,
        date: show.date,
        time: show.time,
        seats: seats,
        snacks: snacks,
        fee: feeTotal,
        discount: discount,
        coupon: coupon,
        method: method,
        amount: grandTotal()
      });

      dbSet(LAST_KEY, booking.id);
      localStorage.removeItem(PENDING_KEY);
      window.location.href = 'booking-success.html';
    }, 900);
  });

  drawBill();
}

/* --------------------------------------------------------------------------
   TICKET CARD  (used by the success page and My Bookings)
   -------------------------------------------------------------------------- */
function ticketCard(b, withActions) {
  const movie = getMovieById(b.movieId);
  const bars  = new Array(38).fill('<i></i>').join('');
  const past  = b.date < todayISO();

  return `
    <article class="ticket ${b.status === 'cancelled' ? 'is-cancelled' : ''}">
      <div class="ticket__main">
        <div class="row-between mb-2">
          <div class="row">
            ${movie ? `<img src="${movie.poster}" alt="" style="width:46px;border-radius:8px">` : ''}
            <div>
              <h3>${esc(b.movieTitle)}</h3>
              <p class="text-xs text-muted">${esc(b.screen)} · ${movie ? esc(movie.format) : ''} · ${movie ? esc(movie.language) : ''}</p>
            </div>
          </div>
          <span class="badge ${b.status === 'cancelled' ? 'badge--danger' : (past ? '' : 'badge--success')}">
            ${b.status === 'cancelled' ? 'Cancelled' : (past ? 'Completed' : 'Confirmed')}
          </span>
        </div>

        <div class="ticket__grid">
          <div><span>Date</span><strong>${prettyDate(b.date)}</strong></div>
          <div><span>Time</span><strong>${prettyTime(b.time)}</strong></div>
          <div><span>Seats</span><strong>${b.seats.join(', ')}</strong></div>
          <div><span>Amount paid</span><strong>${money(b.amount)}</strong></div>
        </div>

        ${b.snacks && b.snacks.length
          ? `<p class="text-xs text-muted mt-4">🍿 ${b.snacks.map(s => esc(s.name) + ' × ' + s.qty).join(', ')}</p>` : ''}

        ${withActions && b.status === 'confirmed' && !past
          ? `<div class="row mt-4">
               <button class="btn btn--ghost btn--sm" data-cancel="${b.id}">Cancel booking</button>
               <button class="btn btn--soft btn--sm" onclick="window.print()">Print</button>
             </div>` : ''}
      </div>

      <div class="ticket__stub">
        <span class="text-xs text-muted">BOOKING ID</span>
        <span class="ticket__code">${esc(b.id)}</span>
        <div class="barcode">${bars}</div>
        <span class="text-xs text-muted">${b.seats.length} ticket${b.seats.length > 1 ? 's' : ''}</span>
      </div>
    </article>`;
}

/* --------------------------------------------------------------------------
   BOOKING SUCCESS PAGE
   -------------------------------------------------------------------------- */
function initSuccessPage() {
  const id = dbGet(LAST_KEY, null);
  const booking = id ? getBookingById(id) : null;
  const wrap = document.getElementById('ticketWrap');

  if (!booking) {
    wrap.innerHTML = `
      <div class="empty">
        <div class="empty__icon">🎟️</div>
        <h3>No recent booking found</h3>
        <p>Start a new booking to get your ticket.</p>
        <a class="btn btn--primary mt-4" href="movies.html">Browse movies</a>
      </div>`;
    return;
  }
  wrap.innerHTML = ticketCard(booking, false);
}

/* --------------------------------------------------------------------------
   MY BOOKINGS PAGE
   -------------------------------------------------------------------------- */
function initMyBookingsPage() {
  if (!requireUser()) return;

  const list = document.getElementById('bookingList');
  const tabs = document.getElementById('bookingTabs');
  let which  = 'upcoming';

  function render() {
    const all = getBookingsByUser(currentUser().id)
      .sort((a, b) => new Date(b.bookedAt) - new Date(a.bookedAt));

    const today = todayISO();
    let shown = all;

    if (which === 'upcoming')  shown = all.filter(b => b.status === 'confirmed' && b.date >= today);
    if (which === 'past')      shown = all.filter(b => b.status === 'confirmed' && b.date <  today);
    if (which === 'cancelled') shown = all.filter(b => b.status === 'cancelled');

    if (!shown.length) {
      const messages = {
        upcoming:  ['🎬', 'No upcoming shows', 'Book a movie and your ticket will appear right here.'],
        past:      ['🕰️', 'No past bookings yet', 'Movies you have already watched will be listed here.'],
        cancelled: ['🚫', 'Nothing cancelled', 'Good news — you have not cancelled any booking.']
      };
      const m = messages[which];
      list.innerHTML = `
        <div class="empty">
          <div class="empty__icon">${m[0]}</div>
          <h3>${m[1]}</h3>
          <p>${m[2]}</p>
          <a class="btn btn--primary mt-4" href="movies.html">Browse movies</a>
        </div>`;
      return;
    }

    list.innerHTML = shown.map(b => ticketCard(b, true)).join('');
  }

  tabs.addEventListener('click', function (e) {
    const tab = e.target.closest('.tab');
    if (!tab) return;
    which = tab.getAttribute('data-tab');
    tabs.querySelectorAll('.tab').forEach(t => t.classList.remove('is-active'));
    tab.classList.add('is-active');
    render();
  });

  list.addEventListener('click', function (e) {
    const btn = e.target.closest('[data-cancel]');
    if (!btn) return;
    const id = btn.getAttribute('data-cancel');

    askConfirm('Cancel this booking?', 'The seats will be released and the amount refunded in 5 to 7 working days.', function () {
      cancelBooking(id);
      toast('Booking cancelled successfully', 'success');
      render();
    });
  });

  render();
}

/* --------------------------------------------------------------------------
   LOGIN PAGE
   -------------------------------------------------------------------------- */
function initLoginPage() {
  if (isLoggedIn()) { window.location.href = 'index.html'; return; }

  const form = document.getElementById('loginForm');

  setupForm(form, {
    loginEmail:    [Rule.required('Please enter your email'), Rule.pattern(RX.email, 'That does not look like a valid email')],
    loginPassword: [Rule.required('Please enter your password'), Rule.minLen(6, 'Password must be at least 6 characters')]
  }, function () {
    const result = loginUser(
      document.getElementById('loginEmail').value,
      document.getElementById('loginPassword').value
    );

    if (!result.ok) {
      showError(document.getElementById('loginPassword'), result.message);
      toast(result.message, 'error');
      return;
    }

    toast('Welcome back, ' + result.user.name.split(' ')[0] + '!', 'success');
    const next = urlParam('next');
    setTimeout(function () {
      window.location.href = next ? decodeURIComponent(next) : 'index.html';
    }, 700);
  });
}

/* --------------------------------------------------------------------------
   SIGN UP PAGE
   -------------------------------------------------------------------------- */
function initSignupPage() {
  if (isLoggedIn()) { window.location.href = 'index.html'; return; }

  const form     = document.getElementById('signupForm');
  const password = document.getElementById('suPassword');

  digitsOnly(document.getElementById('suPhone'), 10);
  bindStrengthMeter(password, document.getElementById('pwMeter'));

  setupForm(form, {
    suName:    [Rule.required('Please enter your name'), Rule.pattern(RX.name, 'Only letters and spaces, at least 3 characters')],
    suEmail:   [Rule.required('Please enter your email'), Rule.pattern(RX.email, 'That does not look like a valid email'),
                Rule.custom(v => !findUserByEmail(v), 'This email is already registered')],
    suPhone:   [Rule.required('Please enter your mobile number'), Rule.pattern(RX.phone, 'Enter a 10 digit number starting with 6-9')],
    suPassword:[Rule.required('Please create a password'), Rule.strongPassword()],
    suConfirm: [Rule.required('Please confirm your password'), Rule.sameAs(password, 'Both passwords must be the same')],
    suTerms:   [Rule.checked('Please accept the terms to continue')]
  }, function () {
    const result = registerUser(
      document.getElementById('suName').value,
      document.getElementById('suEmail').value,
      document.getElementById('suPhone').value,
      password.value
    );

    if (!result.ok) { toast(result.message, 'error'); return; }

    toast('Account created. Welcome to CineSeat!', 'success');
    setTimeout(() => window.location.href = 'index.html', 800);
  });
}

/* --------------------------------------------------------------------------
   RUN THE RIGHT CODE FOR THE PAGE THAT IS OPEN
   -------------------------------------------------------------------------- */
document.addEventListener('DOMContentLoaded', function () {
  bindPasswordToggles();

  if (document.getElementById('nowShowingGrid')) initHome();
  if (document.getElementById('movieGrid'))      initMoviesPage();
  if (document.getElementById('detailWrap'))     initDetailsPage();
  if (document.getElementById('seatArea'))       initSeatsPage();
  if (document.getElementById('payForm'))        initCheckoutPage();
  if (document.getElementById('ticketWrap'))     initSuccessPage();
  if (document.getElementById('bookingList'))    initMyBookingsPage();
  if (document.getElementById('loginForm'))      initLoginPage();
  if (document.getElementById('signupForm'))     initSignupPage();
});
