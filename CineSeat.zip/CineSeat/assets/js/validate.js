/* ==========================================================================
   CineSeat  -  validate.js
   All the JavaScript form validation of the project lives here.
   Every form on the site (signup, login, checkout, admin forms) is
   built from the same small set of rules, so the code stays short.
   ========================================================================== */

/* --------------------------------------------------------------------------
   1. PATTERNS
   -------------------------------------------------------------------------- */
const RX = {
  name:  /^[A-Za-z][A-Za-z. ]{2,39}$/,             // letters, dot and spaces, 3-40 chars
  email: /^[^\s@]+@[^\s@]+\.[A-Za-z]{2,}$/,        // something@something.com
  phone: /^[6-9][0-9]{9}$/,                        // Indian mobile: 10 digits, starts 6-9
  upi:   /^[A-Za-z0-9._-]{2,}@[A-Za-z]{2,}$/,      // name@bank
  cvv:   /^[0-9]{3}$/,
  expiry:/^(0[1-9]|1[0-2])\/([0-9]{2})$/           // MM/YY
};

/* --------------------------------------------------------------------------
   2. SHOWING AND HIDING THE ERROR MESSAGE
   Each input has a <small class="error-msg"> right below it.
   -------------------------------------------------------------------------- */
function errorBoxOf(input) {
  const field = input.closest('.field') || input.parentElement;
  return field ? field.querySelector('.error-msg') : null;
}

function showError(input, message) {
  input.classList.add('is-invalid');
  input.classList.remove('is-valid');
  const box = errorBoxOf(input);
  if (box) {
    box.textContent = message;
    box.classList.add('is-shown');
  }
}

function clearError(input) {
  input.classList.remove('is-invalid');
  if (input.value && input.type !== 'checkbox') input.classList.add('is-valid');
  const box = errorBoxOf(input);
  if (box) box.classList.remove('is-shown');
}

/* --------------------------------------------------------------------------
   3. RULE BUILDERS
   A rule is simply { test: function(value, input){...}, msg: 'error text' }
   -------------------------------------------------------------------------- */
const Rule = {
  required: msg => ({ test: v => v.length > 0, msg: msg || 'This field is required' }),

  pattern: (rx, msg) => ({ test: v => rx.test(v), msg: msg }),

  minLen: (n, msg) => ({ test: v => v.length >= n, msg: msg || ('Enter at least ' + n + ' characters') }),

  maxLen: (n, msg) => ({ test: v => v.length <= n, msg: msg || ('Use at most ' + n + ' characters') }),

  /* number must sit between min and max */
  range: (min, max, msg) => ({
    test: v => !isNaN(Number(v)) && Number(v) >= min && Number(v) <= max,
    msg: msg || ('Enter a number between ' + min + ' and ' + max)
  }),

  /* must be the same as another input (confirm password) */
  sameAs: (otherInput, msg) => ({
    test: v => v === otherInput.value,
    msg: msg || 'Values do not match'
  }),

  /* checkbox must be ticked */
  checked: msg => ({ test: (v, el) => el.checked, msg: msg || 'Please tick this box' }),

  /* strong password: 8+ chars, upper, lower, digit and a symbol */
  strongPassword: () => ({
    test: v => v.length >= 8 && /[A-Z]/.test(v) && /[a-z]/.test(v) && /[0-9]/.test(v) && /[^A-Za-z0-9]/.test(v),
    msg: 'Use 8+ characters with a capital, a small letter, a number and a symbol'
  }),

  /* date must not be in the past */
  notPastDate: msg => ({ test: v => v >= todayISO(), msg: msg || 'Please choose today or a future date' }),

  /* write your own check for one special case */
  custom: (fn, msg) => ({ test: fn, msg: msg })
};

/* --------------------------------------------------------------------------
   4. RUNNING THE RULES
   -------------------------------------------------------------------------- */
function checkField(input, rules) {
  const value = (input.value || '').trim();

  for (let i = 0; i < rules.length; i++) {
    if (!rules[i].test(value, input)) {
      showError(input, rules[i].msg);
      return false;
    }
  }
  clearError(input);
  return true;
}

/* Validate a whole form at once. "fields" looks like { inputId: [rules] } */
function checkForm(form, fields) {
  let allGood = true;
  let firstBad = null;

  Object.keys(fields).forEach(function (id) {
    const input = form.querySelector('#' + id);
    if (!input) return;
    if (!checkField(input, fields[id])) {
      allGood = false;
      if (!firstBad) firstBad = input;
    }
  });

  if (firstBad) firstBad.focus();
  return allGood;
}

/* --------------------------------------------------------------------------
   5. CONNECT A FORM
   - checks a field when the user leaves it (blur)
   - re-checks while typing, but only after it has already failed once
   - on submit: stops the page reload, checks everything, then calls onValid()
   -------------------------------------------------------------------------- */
function setupForm(form, fields, onValid) {
  if (!form) return;

  Object.keys(fields).forEach(function (id) {
    const input = form.querySelector('#' + id);
    if (!input) return;

    input.addEventListener('blur', function () { checkField(input, fields[id]); });

    input.addEventListener('input', function () {
      if (input.classList.contains('is-invalid')) checkField(input, fields[id]);
    });

    if (input.type === 'checkbox' || input.tagName === 'SELECT') {
      input.addEventListener('change', function () { checkField(input, fields[id]); });
    }
  });

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (checkForm(form, fields)) onValid(form);
    else toast('Please fix the highlighted fields', 'error');
  });
}

/* --------------------------------------------------------------------------
   6. PASSWORD STRENGTH METER
   -------------------------------------------------------------------------- */
function passwordScore(pw) {
  let score = 0;
  if (pw.length >= 8)          score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/[0-9]/.test(pw))        score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  if (pw.length >= 12 && score === 4) score = 5;
  return score;                     // 0 to 5
}

function bindStrengthMeter(passwordInput, meterEl) {
  if (!passwordInput || !meterEl) return;

  const fill  = meterEl.querySelector('.strength__fill');
  const label = meterEl.querySelector('.strength__text');

  const levels = [
    { w: '0%',   c: 'var(--danger)',  t: '' },
    { w: '25%',  c: 'var(--danger)',  t: 'Very weak' },
    { w: '45%',  c: 'var(--danger)',  t: 'Weak' },
    { w: '65%',  c: 'var(--warn)',    t: 'Okay' },
    { w: '85%',  c: 'var(--success)', t: 'Strong' },
    { w: '100%', c: 'var(--success)', t: 'Very strong' }
  ];

  passwordInput.addEventListener('input', function () {
    const level = levels[passwordScore(passwordInput.value)];
    fill.style.width = level.w;
    fill.style.background = level.c;
    label.textContent = level.t;
    label.style.color = level.c;
  });
}

/* --------------------------------------------------------------------------
   7. PAYMENT HELPERS  (used on the checkout page)
   -------------------------------------------------------------------------- */

/* Luhn algorithm - the real check banks use to spot a mistyped card number */
function luhnCheck(cardNumber) {
  const digits = String(cardNumber).replace(/\D/g, '');
  if (digits.length !== 16) return false;

  let sum = 0;
  let double = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let d = Number(digits[i]);
    if (double) {
      d = d * 2;
      if (d > 9) d = d - 9;
    }
    sum += d;
    double = !double;
  }
  return sum % 10 === 0;
}

/* Type 4111111111111111 and see 4111 1111 1111 1111 */
function formatCardInput(input) {
  input.addEventListener('input', function () {
    const digits = input.value.replace(/\D/g, '').slice(0, 16);
    input.value = digits.replace(/(.{4})/g, '$1 ').trim();
  });
}

/* Type 1226 and see 12/26 */
function formatExpiryInput(input) {
  input.addEventListener('input', function () {
    let digits = input.value.replace(/\D/g, '').slice(0, 4);
    if (digits.length > 2) digits = digits.slice(0, 2) + '/' + digits.slice(2);
    input.value = digits;
  });
}

/* Is this MM/YY card expiry still in the future? */
function expiryIsFuture(value) {
  const parts = RX.expiry.exec(value);
  if (!parts) return false;

  const month = Number(parts[1]);
  const year  = 2000 + Number(parts[2]);
  const now   = new Date();
  const last  = new Date(year, month, 0);       // last day of that month
  return last >= new Date(now.getFullYear(), now.getMonth(), 1);
}

/* Only digits may be typed in this box (phone, cvv, pincode ...) */
function digitsOnly(input, maxLength) {
  input.addEventListener('input', function () {
    input.value = input.value.replace(/\D/g, '').slice(0, maxLength);
  });
}
