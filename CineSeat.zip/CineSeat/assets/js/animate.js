/* ==========================================================================
   CineSeat  -  animate.js
   The JavaScript half of the animations:
     · reveal cards and panels while scrolling
     · a scroll progress bar and a "back to top" button
     · counting-up numbers on the dashboard
     · stagger for the seat map and the dashboard chart
     · confetti after a successful booking
   This file is loaded LAST, so everything on the page is already drawn.
   ========================================================================== */

/* --------------------------------------------------------------------------
   1. REVEAL ON SCROLL
   Cards and panels start invisible and slightly moved. IntersectionObserver
   tells us the moment one scrolls into view, and then it slides into place.

   A MutationObserver also watches the page. So when user.js or admin.js
   redraws a list - after a search, a filter, or picking another date - the
   brand new cards are picked up automatically and animate in as well.
   -------------------------------------------------------------------------- */
const REVEAL_TARGETS = [
  '.movie-card', '.feature', '.offer', '.cta-band', '.panel', '.card',
  '.stat', '.rank', '.screen-block', '.cast', '.date-pill', '.ticket',
  '.table tbody tr', '.snack', '.filters', '.toolbar', '.tabs', '.seat-panel'
].join(', ');

let revealWatcher = null;

/* Make one element ready to be revealed */
function prepareReveal(el) {
  if (el.dataset.reveal) return;              /* already handled */
  el.dataset.reveal = 'yes';
  el.classList.add('reveal');
  revealWatcher.observe(el);
}

/* Find everything inside "root" that should be revealed */
function scanForReveals(root) {
  if (!revealWatcher) return;

  if (root.nodeType === 1 && root.matches && root.matches(REVEAL_TARGETS)) {
    prepareReveal(root);
  }
  if (root.querySelectorAll) {
    root.querySelectorAll(REVEAL_TARGETS).forEach(prepareReveal);
  }
}

function initReveal() {
  /* very old browsers: skip the effect, everything just stays visible */
  if (!('IntersectionObserver' in window)) return;

  revealWatcher = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (!entry.isIntersecting) return;

      const el = entry.target;
      revealWatcher.unobserve(el);            /* animate only once */

      /* This callback runs a moment after the element was seen, so the page
         may already have replaced it (a new search, a new filter). If it is
         no longer on the page there is nothing left to animate. */
      if (!el.parentElement) return;

      /* items sitting next to each other appear one after the other */
      const siblings = Array.prototype.slice.call(el.parentElement.children);
      const position = siblings.indexOf(el);
      el.style.transitionDelay = Math.min(position, 7) * 70 + 'ms';

      el.classList.add('is-visible');
    });
  }, {
    threshold: 0.08,
    rootMargin: '0px 0px -50px 0px'           /* start a little before the edge */
  });

  scanForReveals(document.body);

  /* watch for cards added later by the page scripts */
  if ('MutationObserver' in window) {
    new MutationObserver(function (changes) {
      changes.forEach(function (change) {
        change.addedNodes.forEach(function (node) {
          if (node.nodeType === 1) scanForReveals(node);
        });
      });
    }).observe(document.body, { childList: true, subtree: true });
  }
}

/* --------------------------------------------------------------------------
   2. SCROLL PROGRESS BAR + BACK TO TOP BUTTON + NAVBAR SHADOW
   -------------------------------------------------------------------------- */
function initScrollEffects() {
  const bar = document.createElement('div');
  bar.id = 'scrollBar';
  document.body.appendChild(bar);

  const toTop = document.createElement('button');
  toTop.id = 'toTop';
  toTop.type = 'button';
  toTop.innerHTML = '↑';
  toTop.setAttribute('aria-label', 'Back to top');
  document.body.appendChild(toTop);

  toTop.addEventListener('click', function () {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  const nav = document.querySelector('.nav');

  function onScroll() {
    const scrolled = window.scrollY;
    const height   = document.documentElement.scrollHeight - window.innerHeight;

    bar.style.width = (height > 0 ? (scrolled / height) * 100 : 0) + '%';
    toTop.classList.toggle('is-shown', scrolled > 420);
    if (nav) nav.classList.toggle('is-scrolled', scrolled > 8);
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
}

/* --------------------------------------------------------------------------
   3. COUNTING NUMBERS  (dashboard tiles and the home page stats)
   "₹12,450" counts up from ₹0 in about one second.
   -------------------------------------------------------------------------- */
function countUp(el) {
  const parts = el.textContent.trim().match(/^(\D*)([\d,]+)(.*)$/);
  if (!parts) return;

  const target = Number(parts[2].replace(/,/g, ''));
  if (!target || target > 9999999) return;

  const started = Date.now();
  const time    = 900;

  function tick() {
    const progress = Math.min(1, (Date.now() - started) / time);
    const eased    = 1 - Math.pow(1 - progress, 3);          /* fast, then slow */
    el.textContent = parts[1] + Math.round(target * eased).toLocaleString('en-IN') + parts[3];
    if (progress < 1) requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}

function initCounters() {
  document.querySelectorAll('.stat__value, .hero__stats strong').forEach(countUp);
}

/* --------------------------------------------------------------------------
   4. STAGGER : seats and chart bars
   -------------------------------------------------------------------------- */
function initStagger() {
  /* seat map: each row starts a little later than the one above */
  document.querySelectorAll('.seat-row').forEach(function (row, rowIndex) {
    row.querySelectorAll('.seat').forEach(function (seat, seatIndex) {
      seat.style.animationDelay = (rowIndex * 45 + seatIndex * 6) + 'ms';
    });
  });

  /* dashboard chart: bars grow one after another */
  document.querySelectorAll('.chart__bar').forEach(function (bar, i) {
    bar.style.animationDelay = (i * 70) + 'ms';
  });

  /* small progress bars inside tables */
  document.querySelectorAll('.mini-bar i').forEach(function (fill, i) {
    fill.style.animationDelay = Math.min(i, 10) * 40 + 'ms';
  });
}

/* --------------------------------------------------------------------------
   5. CONFETTI
   Small coloured pieces fall down the screen. Pure CSS + a few random
   numbers - no external library.
   -------------------------------------------------------------------------- */
function launchConfetti(pieces) {
  const colours = ['#6C4FE0', '#A08CFF', '#2E9E6B', '#E8B93B', '#FF7B77', '#4FD1B5'];

  const box = document.createElement('div');
  box.className = 'confetti';
  box.setAttribute('aria-hidden', 'true');
  document.body.appendChild(box);

  for (let i = 0; i < pieces; i++) {
    const bit = document.createElement('i');

    bit.style.left              = Math.random() * 100 + '%';
    bit.style.background        = colours[i % colours.length];
    bit.style.animationDelay    = (Math.random() * 1.4) + 's';
    bit.style.animationDuration = (2.4 + Math.random() * 1.8) + 's';
    bit.style.setProperty('--x', (Math.random() * 220 - 110) + 'px');
    bit.style.setProperty('--r', (Math.random() * 900 - 450) + 'deg');

    if (i % 3 === 0) bit.style.borderRadius = '50%';          /* round pieces */
    if (i % 4 === 0) bit.style.height = '9px';                /* small squares */

    box.appendChild(bit);
  }

  /* clean up so the page does not keep hundreds of extra elements */
  setTimeout(function () { box.remove(); }, 6000);
}

/* --------------------------------------------------------------------------
   6. START
   -------------------------------------------------------------------------- */
document.addEventListener('DOMContentLoaded', function () {
  /* if the user's system asks for less motion, do nothing at all */
  const calmMode = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  initScrollEffects();

  if (calmMode) return;

  initReveal();
  initCounters();
  initStagger();

  /* the ticket page celebrates a completed booking */
  if (document.querySelector('#ticketWrap .ticket__code')) {
    launchConfetti(110);
  }
});
