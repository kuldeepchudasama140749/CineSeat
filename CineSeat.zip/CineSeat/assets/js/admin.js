/* ==========================================================================
   CineSeat  -  admin.js
   Everything the admin panel does: dashboard numbers, movie CRUD,
   showtime CRUD, bookings, users and settings.
   ========================================================================== */

/* Poster files that exist inside assets/img/posters/ */
const POSTER_FILES = [
  'jawan', 'oppenheimer', 'dune-two', '12th-fail', 'interstellar', 'stree-2',
  'kalki', 'laapataa', 'animal', 'fighter', 'singham', 'munjya'
];

/* Admin pages sit inside /admin/, so images need one folder up */
function apath(p) { return '../' + p; }

/* How many seats are there in one hall */
const HALL_SIZE = 120;

/* --------------------------------------------------------------------------
   SIDEBAR : small counters + logout button
   -------------------------------------------------------------------------- */
function initAdminShell() {
  const counts = {
    countMovies:   getMovies().length,
    countShows:    getShows().length,
    countBookings: getBookings().length,
    countUsers:    getUsers().length
  };
  Object.keys(counts).forEach(function (id) {
    const el = document.getElementById(id);
    if (el) el.textContent = counts[id];
  });

  const out = document.getElementById('adminLogout');
  if (out) {
    out.addEventListener('click', function () {
      askConfirm('Log out of the admin panel?', 'You will need to sign in again to manage the cinema.', function () {
        logout('login.html');
      });
    });
  }
}

/* --------------------------------------------------------------------------
   ADMIN LOGIN PAGE
   -------------------------------------------------------------------------- */
function initAdminLogin() {
  if (isAdmin()) { window.location.href = 'dashboard.html'; return; }

  const form = document.getElementById('adminLoginForm');

  document.querySelectorAll('.pw-toggle').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const input = document.getElementById(btn.getAttribute('data-pw'));
      const showing = input.type === 'text';
      input.type = showing ? 'password' : 'text';
      btn.textContent = showing ? '👁️' : '🙈';
    });
  });

  setupForm(form, {
    adEmail:    [Rule.required('Please enter the admin email'), Rule.pattern(RX.email, 'That is not a valid email address')],
    adPassword: [Rule.required('Please enter the password'), Rule.minLen(6, 'Password must be at least 6 characters')]
  }, function () {
    const result = loginAdmin(
      document.getElementById('adEmail').value,
      document.getElementById('adPassword').value
    );

    if (!result.ok) {
      showError(document.getElementById('adPassword'), result.message);
      toast(result.message, 'error');
      return;
    }
    toast('Welcome back, Admin!', 'success');
    setTimeout(() => window.location.href = 'dashboard.html', 600);
  });
}

/* --------------------------------------------------------------------------
   DASHBOARD
   -------------------------------------------------------------------------- */
function initDashboard() {
  const bookings  = getBookings();
  const confirmed = bookings.filter(b => b.status === 'confirmed');
  const movies    = getMovies();
  const shows     = getShows();

  const revenue   = confirmed.reduce((sum, b) => sum + b.amount, 0);
  const seatsSold = confirmed.reduce((sum, b) => sum + b.seats.length, 0);

  /* average occupancy over every scheduled show */
  let filled = 0;
  shows.forEach(s => { filled += getOccupiedSeats(s.id).length; });
  const occupancy = shows.length ? Math.round((filled / (shows.length * HALL_SIZE)) * 100) : 0;

  /* ---- the four tiles ---- */
  const tiles = [
    ['💰', 'Total revenue', money(revenue),        confirmed.length + ' confirmed bookings'],
    ['🎟️', 'Tickets sold',  seatsSold,             'across ' + shows.length + ' shows'],
    ['📈', 'Avg occupancy', occupancy + '%',       occupancy > 50 ? 'Halls are filling well' : 'Room for more'],
    ['🎬', 'Active movies', movies.filter(m => m.status === 'now').length, movies.filter(m => m.status === 'soon').length + ' coming soon']
  ];

  document.getElementById('statGrid').innerHTML = tiles.map(t => `
    <div class="stat">
      <div class="stat__icon">${t[0]}</div>
      <div class="stat__label">${t[1]}</div>
      <div class="stat__value">${t[2]}</div>
      <div class="stat__note">${t[3]}</div>
    </div>`).join('');

  /* ---- revenue chart for the last 7 days ---- */
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    days.push({ key: key, label: d.toLocaleDateString('en-IN', { weekday: 'short' }), total: 0 });
  }

  confirmed.forEach(function (b) {
    const key = String(b.bookedAt).slice(0, 10);
    const day = days.find(d => d.key === key);
    if (day) day.total += b.amount;
  });

  const biggest = Math.max.apply(null, days.map(d => d.total).concat([1]));

  document.getElementById('revenueChart').innerHTML = days.map(d => `
    <div class="chart__col" title="${d.label}: ${money(d.total)}">
      <span class="chart__val">${d.total ? '₹' + Math.round(d.total / 1000) + 'k' : '0'}</span>
      <div class="chart__bar" style="height:${Math.max(4, (d.total / biggest) * 100)}%"></div>
      <span class="chart__day">${d.label}</span>
    </div>`).join('');

  document.getElementById('weekTotal').textContent =
    money(days.reduce((sum, d) => sum + d.total, 0)) + ' this week';

  /* ---- top movies by number of bookings ---- */
  const tally = {};
  confirmed.forEach(function (b) {
    if (!tally[b.movieId]) tally[b.movieId] = { count: 0, amount: 0 };
    tally[b.movieId].count += b.seats.length;
    tally[b.movieId].amount += b.amount;
  });

  const top = Object.keys(tally)
    .map(id => ({ movie: getMovieById(id), data: tally[id] }))
    .filter(x => x.movie)
    .sort((a, b) => b.data.count - a.data.count)
    .slice(0, 5);

  const most = top.length ? top[0].data.count : 1;

  document.getElementById('topMovies').innerHTML = top.length ? top.map(x => `
    <div class="rank">
      <img src="${apath(x.movie.poster)}" alt="">
      <div class="grow">
        <strong class="text-sm">${esc(x.movie.title)}</strong>
        <div class="text-xs text-muted">${x.data.count} tickets · ${money(x.data.amount)}</div>
        <div class="rank__bar"><div class="rank__fill" style="width:${(x.data.count / most) * 100}%"></div></div>
      </div>
    </div>`).join('') : '<p class="text-sm text-muted">No bookings yet.</p>';

  /* ---- recent bookings table ---- */
  const recent = bookings.slice().sort((a, b) => new Date(b.bookedAt) - new Date(a.bookedAt)).slice(0, 6);

  document.getElementById('recentBody').innerHTML = recent.map(b => `
    <tr>
      <td data-label="Booking ID"><strong>${esc(b.id)}</strong></td>
      <td data-label="Customer">${esc(b.userName)}<div class="text-xs text-muted">${esc(b.userEmail)}</div></td>
      <td data-label="Movie">${esc(b.movieTitle)}</td>
      <td data-label="Show">${prettyDate(b.date)}<div class="text-xs text-muted">${prettyTime(b.time)} · ${esc(b.screen)}</div></td>
      <td data-label="Seats">${b.seats.join(', ')}</td>
      <td data-label="Amount"><strong>${money(b.amount)}</strong></td>
      <td data-label="Status"><span class="badge ${b.status === 'confirmed' ? 'badge--success' : 'badge--danger'}">${b.status}</span></td>
    </tr>`).join('');
}

/* --------------------------------------------------------------------------
   MOVIES : list, add, edit, delete
   -------------------------------------------------------------------------- */
function initAdminMovies() {
  const body   = document.getElementById('movieBody');
  const empty  = document.getElementById('movieEmpty');
  const search = document.getElementById('movieSearch');
  const status = document.getElementById('movieStatus');
  const form   = document.getElementById('movieForm');

  /* fill the poster dropdown */
  document.getElementById('mvPoster').innerHTML =
    '<option value="">Choose a poster</option>' +
    POSTER_FILES.map(f => `<option value="assets/img/posters/${f}.svg">${f}.svg</option>`).join('');

  function render() {
    const words = search.value.trim().toLowerCase();
    let list = getMovies();

    if (words)                  list = list.filter(m => m.title.toLowerCase().includes(words) || m.genre.toLowerCase().includes(words));
    if (status.value !== 'all') list = list.filter(m => m.status === status.value);

    body.innerHTML = list.map(function (m) {
      const showCount = getShowsByMovie(m.id).length;
      return `
        <tr>
          <td data-label="Movie">
            <div class="cell-movie">
              <img src="${apath(m.poster)}" alt="">
              <div><strong>${esc(m.title)}</strong><div class="text-xs text-muted">${esc(m.certificate)} · ${esc(m.format)}</div></div>
            </div>
          </td>
          <td data-label="Genre">${esc(m.genre)}</td>
          <td data-label="Language">${esc(m.language)}</td>
          <td data-label="Duration">${prettyDuration(m.duration)}</td>
          <td data-label="Rating">★ ${m.rating}</td>
          <td data-label="Status"><span class="badge ${m.status === 'now' ? 'badge--success' : 'badge--warn'}">${m.status === 'now' ? 'Now showing' : 'Coming soon'}</span></td>
          <td data-label="Shows">${showCount}</td>
          <td data-label="Actions">
            <div class="table__actions">
              <button class="icon-btn icon-btn--sm" data-edit="${m.id}" title="Edit" aria-label="Edit ${esc(m.title)}">✏️</button>
              <button class="icon-btn icon-btn--sm" data-del="${m.id}" title="Delete" aria-label="Delete ${esc(m.title)}">🗑️</button>
            </div>
          </td>
        </tr>`;
    }).join('');

    empty.classList.toggle('hidden', list.length > 0);
    initAdminShell();
  }

  /* ---- open the modal empty (add) or filled (edit) ---- */
  function openMovieModal(movie) {
    form.reset();
    form.querySelectorAll('.input, .select, .textarea').forEach(clearError);
    form.querySelectorAll('.is-valid').forEach(el => el.classList.remove('is-valid'));

    document.getElementById('movieModalTitle').textContent = movie ? 'Edit movie' : 'Add a new movie';
    document.getElementById('movieId').value = movie ? movie.id : '';

    if (movie) {
      document.getElementById('mvTitle').value    = movie.title;
      document.getElementById('mvGenre').value    = movie.genre;
      document.getElementById('mvLanguage').value = movie.language;
      document.getElementById('mvDuration').value = movie.duration;
      document.getElementById('mvRating').value   = movie.rating;
      document.getElementById('mvCert').value     = movie.certificate;
      document.getElementById('mvFormat').value   = movie.format;
      document.getElementById('mvPoster').value   = movie.poster;
      document.getElementById('mvStatus').value   = movie.status;
      document.getElementById('mvCast').value     = movie.cast.join(', ');
      document.getElementById('mvSynopsis').value = movie.synopsis;
    }
    openModal('movieModal');
  }

  document.getElementById('addMovieBtn').addEventListener('click', () => openMovieModal(null));

  body.addEventListener('click', function (e) {
    const edit = e.target.closest('[data-edit]');
    const del  = e.target.closest('[data-del]');

    if (edit) openMovieModal(getMovieById(edit.getAttribute('data-edit')));

    if (del) {
      const movie = getMovieById(del.getAttribute('data-del'));
      const count = getShowsByMovie(movie.id).length;
      askConfirm(
        'Delete "' + movie.title + '"?',
        count ? 'This movie has ' + count + ' scheduled shows. They will be removed too.' : 'This cannot be undone.',
        function () {
          deleteMovie(movie.id);
          toast('Movie deleted', 'success');
          render();
        }
      );
    }
  });

  /* ---- validation rules for the movie form ---- */
  const rules = {
    mvTitle:    [Rule.required('Please enter the movie title'), Rule.minLen(2, 'Title is too short'), Rule.maxLen(60, 'Title is too long')],
    mvGenre:    [Rule.required('Please choose a genre')],
    mvLanguage: [Rule.required('Please choose a language')],
    mvDuration: [Rule.required('Please enter the duration'), Rule.range(30, 300, 'Duration must be between 30 and 300 minutes')],
    mvRating:   [Rule.required('Please enter the rating'), Rule.range(0, 10, 'Rating must be between 0 and 10')],
    mvPoster:   [Rule.required('Please choose a poster image')],
    mvCast:     [Rule.required('Please enter the cast'),
                 Rule.custom(v => v.split(',').filter(x => x.trim().length > 1).length >= 2, 'Enter at least two names separated by commas')],
    mvSynopsis: [Rule.required('Please write a short story'), Rule.minLen(25, 'Write at least 25 characters')]
  };

  setupForm(form, rules, function () {
    const data = {
      title:       document.getElementById('mvTitle').value.trim(),
      genre:       document.getElementById('mvGenre').value,
      language:    document.getElementById('mvLanguage').value,
      duration:    Number(document.getElementById('mvDuration').value),
      rating:      Number(document.getElementById('mvRating').value),
      certificate: document.getElementById('mvCert').value,
      format:      document.getElementById('mvFormat').value,
      poster:      document.getElementById('mvPoster').value,
      status:      document.getElementById('mvStatus').value,
      cast:        document.getElementById('mvCast').value.split(',').map(s => s.trim()).filter(Boolean),
      synopsis:    document.getElementById('mvSynopsis').value.trim()
    };

    const id = document.getElementById('movieId').value;
    if (id) { updateMovie(id, data); toast('Movie updated', 'success'); }
    else    { addMovie(data);        toast('Movie added', 'success'); }

    closeModal('movieModal');
    render();
  });

  search.addEventListener('input', render);
  status.addEventListener('change', render);
  render();
}

/* --------------------------------------------------------------------------
   SHOWTIMES : list, add, edit, delete
   -------------------------------------------------------------------------- */
function initAdminShows() {
  const body   = document.getElementById('showBody');
  const empty  = document.getElementById('showEmpty');
  const form   = document.getElementById('showForm');

  const fMovie  = document.getElementById('showMovieFilter');
  const fDate   = document.getElementById('showDateFilter');
  const fScreen = document.getElementById('showScreenFilter');

  /* fill both movie dropdowns */
  const movieOptions = getMovies().map(m => `<option value="${m.id}">${esc(m.title)}</option>`).join('');
  fMovie.innerHTML = '<option value="all">All movies</option>' + movieOptions;
  document.getElementById('shMovie').innerHTML = '<option value="">Choose a movie</option>' + movieOptions;

  function render() {
    let list = getShows();

    if (fMovie.value  !== 'all') list = list.filter(s => s.movieId === fMovie.value);
    if (fScreen.value !== 'all') list = list.filter(s => s.screen === fScreen.value);
    if (fDate.value)             list = list.filter(s => s.date === fDate.value);

    list.sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));

    body.innerHTML = list.slice(0, 60).map(function (s) {
      const movie = getMovieById(s.movieId);
      const sold  = getOccupiedSeats(s.id).length;
      const pct   = Math.round((sold / HALL_SIZE) * 100);
      const old   = s.date < todayISO();

      return `
        <tr style="${old ? 'opacity:.6' : ''}">
          <td data-label="Movie">
            <div class="cell-movie">
              ${movie ? `<img src="${apath(movie.poster)}" alt="">` : ''}
              <div><strong>${movie ? esc(movie.title) : 'Deleted movie'}</strong>
              <div class="text-xs text-muted">${movie ? esc(movie.format) : ''}</div></div>
            </div>
          </td>
          <td data-label="Screen">${esc(s.screen)}</td>
          <td data-label="Date">${prettyDate(s.date)} ${old ? '<span class="badge">past</span>' : ''}</td>
          <td data-label="Time">${prettyTime(s.time)}</td>
          <td data-label="Prices" class="text-xs">₹${s.price.silver} / ₹${s.price.gold} / ₹${s.price.recliner}</td>
          <td data-label="Occupancy">
            <span class="mini-bar"><i style="width:${pct}%"></i></span>
            <span class="text-xs text-muted"> ${sold}/${HALL_SIZE}</span>
          </td>
          <td data-label="Actions">
            <div class="table__actions">
              <button class="icon-btn icon-btn--sm" data-edit="${s.id}" title="Edit" aria-label="Edit show">✏️</button>
              <button class="icon-btn icon-btn--sm" data-del="${s.id}" title="Delete" aria-label="Delete show">🗑️</button>
            </div>
          </td>
        </tr>`;
    }).join('');

    empty.classList.toggle('hidden', list.length > 0);
    initAdminShell();
  }

  function openShowModal(show) {
    form.reset();
    form.querySelectorAll('.input, .select').forEach(clearError);
    form.querySelectorAll('.is-valid').forEach(el => el.classList.remove('is-valid'));

    document.getElementById('showModalTitle').textContent = show ? 'Edit show' : 'Schedule a show';
    document.getElementById('showId').value = show ? show.id : '';

    const price = getSettings().price;
    document.getElementById('shSilver').value   = show ? show.price.silver   : price.silver;
    document.getElementById('shGold').value     = show ? show.price.gold     : price.gold;
    document.getElementById('shRecliner').value = show ? show.price.recliner : price.recliner;

    if (show) {
      document.getElementById('shMovie').value  = show.movieId;
      document.getElementById('shScreen').value = show.screen;
      document.getElementById('shDate').value   = show.date;
      document.getElementById('shTime').value   = show.time;
    } else {
      document.getElementById('shDate').value = todayISO();
    }
    openModal('showModal');
  }

  document.getElementById('addShowBtn').addEventListener('click', () => openShowModal(null));

  body.addEventListener('click', function (e) {
    const edit = e.target.closest('[data-edit]');
    const del  = e.target.closest('[data-del]');

    if (edit) openShowModal(getShowById(edit.getAttribute('data-edit')));

    if (del) {
      const id = del.getAttribute('data-del');
      const sold = getBookings().filter(b => b.showId === id && b.status === 'confirmed').length;
      askConfirm(
        'Delete this show?',
        sold ? 'Careful: ' + sold + ' customer booking(s) belong to this show.' : 'This show will be removed from the website.',
        function () { deleteShow(id); toast('Show deleted', 'success'); render(); }
      );
    }
  });

  const silver   = document.getElementById('shSilver');
  const gold     = document.getElementById('shGold');

  const rules = {
    shMovie:    [Rule.required('Please choose a movie')],
    shScreen:   [Rule.required('Please choose a screen')],
    shDate:     [Rule.required('Please choose a date'), Rule.notPastDate('You cannot schedule a show in the past')],
    shTime:     [Rule.required('Please choose a time slot')],
    shSilver:   [Rule.required('Enter the silver price'), Rule.range(50, 2000, 'Price must be between ₹50 and ₹2000')],
    shGold:     [Rule.required('Enter the gold price'), Rule.range(50, 2000, 'Price must be between ₹50 and ₹2000'),
                 Rule.custom(v => Number(v) >= Number(silver.value || 0), 'Gold must cost at least as much as Silver')],
    shRecliner: [Rule.required('Enter the recliner price'), Rule.range(50, 2000, 'Price must be between ₹50 and ₹2000'),
                 Rule.custom(v => Number(v) >= Number(gold.value || 0), 'Recliner must cost at least as much as Gold')]
  };

  setupForm(form, rules, function () {
    const id     = document.getElementById('showId').value;
    const screen = document.getElementById('shScreen').value;
    const date   = document.getElementById('shDate').value;
    const time   = document.getElementById('shTime').value;

    /* two shows cannot use the same screen at the same time */
    if (isSlotTaken(screen, date, time, id)) {
      showError(document.getElementById('shTime'), screen + ' already has a show at this time on this date');
      toast('That screen is already busy at this time', 'error');
      return;
    }

    const data = {
      movieId: document.getElementById('shMovie').value,
      screen:  screen,
      date:    date,
      time:    time,
      price: {
        silver:   Number(silver.value),
        gold:     Number(gold.value),
        recliner: Number(document.getElementById('shRecliner').value)
      }
    };

    if (id) { updateShow(id, data); toast('Show updated', 'success'); }
    else    { addShow(data);        toast('Show scheduled', 'success'); }

    closeModal('showModal');
    render();
  });

  fMovie.addEventListener('change', render);
  fScreen.addEventListener('change', render);
  fDate.addEventListener('change', render);
  document.getElementById('clearShowFilters').addEventListener('click', function () {
    fMovie.value = 'all'; fScreen.value = 'all'; fDate.value = '';
    render();
  });

  render();
}

/* --------------------------------------------------------------------------
   BOOKINGS
   -------------------------------------------------------------------------- */
function initAdminBookings() {
  const body   = document.getElementById('bookingBody');
  const empty  = document.getElementById('bookingEmpty');
  const search = document.getElementById('bookingSearch');
  const status = document.getElementById('bookingStatus');
  const sort   = document.getElementById('bookingSort');

  function render() {
    const all       = getBookings();
    const confirmed = all.filter(b => b.status === 'confirmed');

    /* ---- small stat tiles at the top ---- */
    document.getElementById('bookingStats').innerHTML = [
      ['💰', 'Revenue',   money(confirmed.reduce((s, b) => s + b.amount, 0))],
      ['✅', 'Confirmed', confirmed.length],
      ['🚫', 'Cancelled', all.filter(b => b.status === 'cancelled').length],
      ['🪑', 'Seats sold', confirmed.reduce((s, b) => s + b.seats.length, 0)]
    ].map(t => `
      <div class="stat">
        <div class="stat__icon">${t[0]}</div>
        <div class="stat__label">${t[1]}</div>
        <div class="stat__value">${t[2]}</div>
      </div>`).join('');

    /* ---- filter + sort ---- */
    const words = search.value.trim().toLowerCase();
    let list = all;

    if (words) {
      list = list.filter(b =>
        b.id.toLowerCase().includes(words) ||
        String(b.userName).toLowerCase().includes(words) ||
        String(b.userEmail).toLowerCase().includes(words) ||
        String(b.movieTitle).toLowerCase().includes(words)
      );
    }
    if (status.value !== 'all') list = list.filter(b => b.status === status.value);

    if (sort.value === 'new')    list.sort((a, b) => new Date(b.bookedAt) - new Date(a.bookedAt));
    if (sort.value === 'old')    list.sort((a, b) => new Date(a.bookedAt) - new Date(b.bookedAt));
    if (sort.value === 'amount') list.sort((a, b) => b.amount - a.amount);

    body.innerHTML = list.map(b => `
      <tr>
        <td data-label="Booking ID"><strong>${esc(b.id)}</strong></td>
        <td data-label="Customer">${esc(b.userName)}<div class="text-xs text-muted">${esc(b.userEmail)}</div></td>
        <td data-label="Movie">${esc(b.movieTitle)}</td>
        <td data-label="Show">${prettyDate(b.date)}<div class="text-xs text-muted">${prettyTime(b.time)} · ${esc(b.screen)}</div></td>
        <td data-label="Seats">${b.seats.join(', ')}<div class="text-xs text-muted">${b.seats.length} seat(s)</div></td>
        <td data-label="Amount"><strong>${money(b.amount)}</strong></td>
        <td data-label="Booked on" class="text-xs">${prettyStamp(b.bookedAt)}</td>
        <td data-label="Status"><span class="badge ${b.status === 'confirmed' ? 'badge--success' : 'badge--danger'}">${b.status}</span></td>
        <td data-label="Action">
          ${b.status === 'confirmed'
            ? `<button class="btn btn--ghost btn--sm" data-cancel="${b.id}">Cancel</button>`
            : `<span class="text-xs text-muted">—</span>`}
        </td>
      </tr>`).join('');

    empty.classList.toggle('hidden', list.length > 0);
    initAdminShell();
  }

  body.addEventListener('click', function (e) {
    const btn = e.target.closest('[data-cancel]');
    if (!btn) return;
    const id = btn.getAttribute('data-cancel');

    askConfirm('Cancel booking ' + id + '?', 'The seats will be released and the customer will see this as cancelled.', function () {
      cancelBooking(id);
      toast('Booking cancelled', 'success');
      render();
    });
  });

  search.addEventListener('input', render);
  status.addEventListener('change', render);
  sort.addEventListener('change', render);
  render();
}

/* --------------------------------------------------------------------------
   USERS
   -------------------------------------------------------------------------- */
function initAdminUsers() {
  const body   = document.getElementById('userBody');
  const empty  = document.getElementById('userEmpty');
  const search = document.getElementById('userSearch');
  const filter = document.getElementById('userFilter');

  function render() {
    const users = getUsers();

    document.getElementById('userStats').innerHTML = [
      ['👥', 'Total users', users.length],
      ['✅', 'Active',      users.filter(u => !u.blocked).length],
      ['⛔', 'Blocked',     users.filter(u => u.blocked).length],
      ['🎟️', 'Bookings',   getBookings().length]
    ].map(t => `
      <div class="stat">
        <div class="stat__icon">${t[0]}</div>
        <div class="stat__label">${t[1]}</div>
        <div class="stat__value">${t[2]}</div>
      </div>`).join('');

    const words = search.value.trim().toLowerCase();
    let list = users;

    if (words) {
      list = list.filter(u =>
        u.name.toLowerCase().includes(words) ||
        u.email.toLowerCase().includes(words) ||
        String(u.phone).includes(words)
      );
    }
    if (filter.value === 'active')  list = list.filter(u => !u.blocked);
    if (filter.value === 'blocked') list = list.filter(u => u.blocked);

    body.innerHTML = list.map(function (u) {
      const mine  = getBookingsByUser(u.id).filter(b => b.status === 'confirmed');
      const spent = mine.reduce((s, b) => s + b.amount, 0);
      const initials = u.name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();

      return `
        <tr>
          <td data-label="Name">
            <div class="cell-movie">
              <span class="account__avatar">${esc(initials)}</span>
              <strong>${esc(u.name)}</strong>
            </div>
          </td>
          <td data-label="Email">${esc(u.email)}</td>
          <td data-label="Mobile">${esc(u.phone)}</td>
          <td data-label="Joined" class="text-xs">${prettyStamp(u.joinedAt).split(',')[0]}</td>
          <td data-label="Bookings">${mine.length}</td>
          <td data-label="Spent"><strong>${money(spent)}</strong></td>
          <td data-label="Status"><span class="badge ${u.blocked ? 'badge--danger' : 'badge--success'}">${u.blocked ? 'Blocked' : 'Active'}</span></td>
          <td data-label="Actions">
            <div class="table__actions">
              <button class="btn btn--ghost btn--sm" data-block="${u.id}">${u.blocked ? 'Unblock' : 'Block'}</button>
              <button class="icon-btn icon-btn--sm" data-del="${u.id}" title="Delete" aria-label="Delete user">🗑️</button>
            </div>
          </td>
        </tr>`;
    }).join('');

    empty.classList.toggle('hidden', list.length > 0);
    initAdminShell();
  }

  body.addEventListener('click', function (e) {
    const block = e.target.closest('[data-block]');
    const del   = e.target.closest('[data-del]');

    if (block) {
      const user = getUserById(block.getAttribute('data-block'));
      updateUser(user.id, { blocked: !user.blocked });
      toast(user.blocked ? 'User unblocked' : 'User blocked', 'success');
      render();
    }

    if (del) {
      const user = getUserById(del.getAttribute('data-del'));
      askConfirm('Delete ' + user.name + '?', 'Their account will be removed. Past bookings stay in the records.', function () {
        deleteUser(user.id);
        toast('User deleted', 'success');
        render();
      });
    }
  });

  search.addEventListener('input', render);
  filter.addEventListener('change', render);
  render();
}

/* --------------------------------------------------------------------------
   SETTINGS
   -------------------------------------------------------------------------- */
function initAdminSettings() {
  const settings = getSettings();

  /* ---- fill the forms with what is saved ---- */
  document.getElementById('stName').value     = settings.cinemaName;
  document.getElementById('stCity').value     = settings.city;
  document.getElementById('stPhone').value    = settings.phone;
  document.getElementById('stEmail').value    = settings.email;
  document.getElementById('stAddress').value  = settings.address;
  document.getElementById('stSilver').value   = settings.price.silver;
  document.getElementById('stGold').value     = settings.price.gold;
  document.getElementById('stRecliner').value = settings.price.recliner;
  document.getElementById('stFee').value      = settings.convenienceFee;

  /* ---- cinema details form ---- */
  setupForm(document.getElementById('cinemaForm'), {
    stName:    [Rule.required('Please enter the cinema name'), Rule.minLen(3, 'Name is too short')],
    stCity:    [Rule.required('Please enter the city'), Rule.pattern(RX.name, 'Use letters only')],
    stPhone:   [Rule.required('Please enter a phone number'), Rule.custom(v => v.replace(/\D/g, '').length >= 8, 'Enter a valid phone number')],
    stEmail:   [Rule.required('Please enter the support email'), Rule.pattern(RX.email, 'That is not a valid email')],
    stAddress: [Rule.required('Please enter the address'), Rule.minLen(10, 'Write the full address')]
  }, function () {
    const s = getSettings();
    s.cinemaName = document.getElementById('stName').value.trim();
    s.city       = document.getElementById('stCity').value.trim();
    s.phone      = document.getElementById('stPhone').value.trim();
    s.email      = document.getElementById('stEmail').value.trim();
    s.address    = document.getElementById('stAddress').value.trim();
    saveSettings(s);
    toast('Cinema details saved', 'success');
  });

  /* ---- prices form ---- */
  const stSilver = document.getElementById('stSilver');
  const stGold   = document.getElementById('stGold');

  setupForm(document.getElementById('priceForm'), {
    stSilver:   [Rule.required('Enter the silver price'), Rule.range(50, 2000, 'Between ₹50 and ₹2000')],
    stGold:     [Rule.required('Enter the gold price'), Rule.range(50, 2000, 'Between ₹50 and ₹2000'),
                 Rule.custom(v => Number(v) >= Number(stSilver.value || 0), 'Gold must cost at least as much as Silver')],
    stRecliner: [Rule.required('Enter the recliner price'), Rule.range(50, 2000, 'Between ₹50 and ₹2000'),
                 Rule.custom(v => Number(v) >= Number(stGold.value || 0), 'Recliner must cost at least as much as Gold')],
    stFee:      [Rule.required('Enter the convenience fee'), Rule.range(0, 200, 'Fee must be between ₹0 and ₹200')]
  }, function () {
    const s = getSettings();
    s.price = {
      silver:   Number(stSilver.value),
      gold:     Number(stGold.value),
      recliner: Number(document.getElementById('stRecliner').value)
    };
    s.convenienceFee = Number(document.getElementById('stFee').value);
    saveSettings(s);
    toast('Default prices saved', 'success');
  });

  /* ---- theme chips ---- */
  function paintThemeChips() {
    document.querySelectorAll('[data-theme-pick]').forEach(function (chip) {
      chip.classList.toggle('is-active', chip.getAttribute('data-theme-pick') === getTheme());
    });
  }
  document.querySelectorAll('[data-theme-pick]').forEach(function (chip) {
    chip.addEventListener('click', function () {
      setTheme(chip.getAttribute('data-theme-pick'));
      paintThemeChips();
    });
  });
  paintThemeChips();

  /* ---- reset demo data ---- */
  document.getElementById('resetDataBtn').addEventListener('click', function () {
    askConfirm('Reset all demo data?',
      'Every movie, show, user and booking saved in this browser will be replaced with the original demo data.',
      function () {
        resetDemoData();
        toast('Demo data has been reset', 'success');
        setTimeout(() => window.location.reload(), 900);
      });
  });

  /* ---- how much space we are using ---- */
  let bytes = 0;
  Object.values(KEYS).forEach(function (k) {
    const v = localStorage.getItem(k);
    if (v) bytes += v.length;
  });

  document.getElementById('storageInfo').innerHTML = `
    <div class="summary__line"><span>Movies</span><span>${getMovies().length}</span></div>
    <div class="summary__line"><span>Shows</span><span>${getShows().length}</span></div>
    <div class="summary__line"><span>Bookings</span><span>${getBookings().length}</span></div>
    <div class="summary__line"><span>Users</span><span>${getUsers().length}</span></div>
    <div class="summary__total"><span>localStorage used</span><strong>${(bytes / 1024).toFixed(1)} KB</strong></div>`;
}

/* --------------------------------------------------------------------------
   RUN THE RIGHT CODE FOR THE PAGE THAT IS OPEN
   -------------------------------------------------------------------------- */
document.addEventListener('DOMContentLoaded', function () {

  /* the login page is the only admin page that does not need a session */
  if (document.getElementById('adminLoginForm')) { initAdminLogin(); return; }

  if (!requireAdmin()) return;

  initAdminShell();

  if (document.getElementById('statGrid'))    initDashboard();
  if (document.getElementById('movieBody'))   initAdminMovies();
  if (document.getElementById('showBody'))    initAdminShows();
  if (document.getElementById('bookingBody')) initAdminBookings();
  if (document.getElementById('userBody'))    initAdminUsers();
  if (document.getElementById('cinemaForm'))  initAdminSettings();
});
