/* ==========================================================================
   CineSeat  -  store.js
   The "database" of the project. Everything is saved in the browser's
   localStorage as JSON text. Every other file talks to storage ONLY
   through the small helper functions below.
   ========================================================================== */

/* All localStorage key names live in one place so we never mistype them. */
const KEYS = {
  users:    'cs_users',
  movies:   'cs_movies',
  shows:    'cs_shows',
  bookings: 'cs_bookings',
  session:  'cs_session',
  settings: 'cs_settings',
  theme:    'cs_theme',
  seeded:   'cs_seeded'
};

/* --------------------------------------------------------------------------
   Low level read / write
   -------------------------------------------------------------------------- */

/* Read a key and turn the JSON text back into an object/array. */
function dbGet(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw === null ? fallback : JSON.parse(raw);
  } catch (err) {
    console.warn('Could not read', key, err);
    return fallback;
  }
}

/* Save any object/array as JSON text. */
function dbSet(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (err) {
    console.warn('Could not save', key, err);
    return false;
  }
}

/* Make a simple unique id, e.g. makeId('mv') -> "mv-l8k2p1" */
function makeId(prefix) {
  return prefix + '-' + Math.random().toString(36).slice(2, 8);
}

/* --------------------------------------------------------------------------
   MOVIES
   -------------------------------------------------------------------------- */
function getMovies()            { return dbGet(KEYS.movies, []); }
function saveMovies(list)       { dbSet(KEYS.movies, list); }
function getMovieById(id)       { return getMovies().find(m => m.id === id) || null; }
function getNowShowing()        { return getMovies().filter(m => m.status === 'now'); }
function getComingSoon()        { return getMovies().filter(m => m.status === 'soon'); }

function addMovie(movie) {
  const list = getMovies();
  movie.id = makeId('mv');
  list.push(movie);
  saveMovies(list);
  return movie;
}

function updateMovie(id, changes) {
  const list = getMovies();
  const i = list.findIndex(m => m.id === id);
  if (i === -1) return false;
  list[i] = Object.assign(list[i], changes);
  saveMovies(list);
  return true;
}

/* Deleting a movie also removes its shows (otherwise we get orphan shows). */
function deleteMovie(id) {
  saveMovies(getMovies().filter(m => m.id !== id));
  saveShows(getShows().filter(s => s.movieId !== id));
}

/* --------------------------------------------------------------------------
   SHOWS  (a movie + screen + date + time + prices)
   -------------------------------------------------------------------------- */
function getShows()             { return dbGet(KEYS.shows, []); }
function saveShows(list)        { dbSet(KEYS.shows, list); }
function getShowById(id)        { return getShows().find(s => s.id === id) || null; }
function getShowsByMovie(mid)   { return getShows().filter(s => s.movieId === mid); }

function addShow(show) {
  const list = getShows();
  show.id = makeId('sh');
  show.preBooked = show.preBooked || [];
  list.push(show);
  saveShows(list);
  return show;
}

function updateShow(id, changes) {
  const list = getShows();
  const i = list.findIndex(s => s.id === id);
  if (i === -1) return false;
  list[i] = Object.assign(list[i], changes);
  saveShows(list);
  return true;
}

function deleteShow(id) { saveShows(getShows().filter(s => s.id !== id)); }

/* Is this exact screen already used at this date + time? (used by validation) */
function isSlotTaken(screen, date, time, ignoreId) {
  return getShows().some(s =>
    s.screen === screen && s.date === date && s.time === time && s.id !== ignoreId
  );
}

/* --------------------------------------------------------------------------
   BOOKINGS
   -------------------------------------------------------------------------- */
function getBookings()          { return dbGet(KEYS.bookings, []); }
function saveBookings(list)     { dbSet(KEYS.bookings, list); }
function getBookingById(id)     { return getBookings().find(b => b.id === id) || null; }
function getBookingsByUser(uid) { return getBookings().filter(b => b.userId === uid); }

/* Booking ids look like CS-48210 so they are easy to read on a ticket. */
function makeBookingId() {
  return 'CS-' + Math.floor(10000 + Math.random() * 89999);
}

function addBooking(booking) {
  const list = getBookings();
  booking.id = makeBookingId();
  booking.bookedAt = new Date().toISOString();
  booking.status = 'confirmed';
  list.push(booking);
  saveBookings(list);
  return booking;
}

function cancelBooking(id) {
  const list = getBookings();
  const b = list.find(x => x.id === id);
  if (!b) return false;
  b.status = 'cancelled';
  saveBookings(list);
  return true;
}

/* Every seat that can NOT be picked for a show:
   the seats seeded as already sold + seats from real confirmed bookings. */
function getOccupiedSeats(showId) {
  const show = getShowById(showId);
  const taken = show && show.preBooked ? show.preBooked.slice() : [];
  getBookings().forEach(b => {
    if (b.showId === showId && b.status === 'confirmed') {
      b.seats.forEach(seat => { if (!taken.includes(seat)) taken.push(seat); });
    }
  });
  return taken;
}

/* --------------------------------------------------------------------------
   USERS
   -------------------------------------------------------------------------- */
function getUsers()             { return dbGet(KEYS.users, []); }
function saveUsers(list)        { dbSet(KEYS.users, list); }
function getUserById(id)        { return getUsers().find(u => u.id === id) || null; }

function findUserByEmail(email) {
  const clean = String(email).trim().toLowerCase();
  return getUsers().find(u => u.email.toLowerCase() === clean) || null;
}

function addUser(user) {
  const list = getUsers();
  user.id = makeId('us');
  user.joinedAt = new Date().toISOString();
  user.blocked = false;
  list.push(user);
  saveUsers(list);
  return user;
}

function updateUser(id, changes) {
  const list = getUsers();
  const i = list.findIndex(u => u.id === id);
  if (i === -1) return false;
  list[i] = Object.assign(list[i], changes);
  saveUsers(list);
  return true;
}

function deleteUser(id) { saveUsers(getUsers().filter(u => u.id !== id)); }

/* --------------------------------------------------------------------------
   SETTINGS  (edited on the admin settings page)
   -------------------------------------------------------------------------- */
function getSettings() {
  return dbGet(KEYS.settings, {
    cinemaName: 'CineSeat Multiplex',
    city: 'Ahmedabad',
    address: 'SG Highway, Ahmedabad, Gujarat 380015',
    email: 'support@cineseat.com',
    phone: '1800 200 4040',
    price: { silver: 180, gold: 250, recliner: 450 },
    convenienceFee: 35
  });
}

function saveSettings(obj) { dbSet(KEYS.settings, obj); }

/* --------------------------------------------------------------------------
   SMALL FORMATTING HELPERS  (used all over the site)
   -------------------------------------------------------------------------- */

/* 1250 -> "₹1,250" */
function money(n) {
  return '₹' + Number(n || 0).toLocaleString('en-IN');
}

/* "2026-08-24" -> "Mon, 24 Aug" */
function prettyDate(iso) {
  const d = new Date(iso + 'T00:00:00');
  if (isNaN(d)) return iso;
  return d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
}

/* "14:30" -> "2:30 PM" */
function prettyTime(hhmm) {
  const parts = String(hhmm).split(':');
  let h = Number(parts[0]);
  const m = parts[1] || '00';
  const suffix = h >= 12 ? 'PM' : 'AM';
  h = h % 12 || 12;
  return h + ':' + m + ' ' + suffix;
}

/* ISO timestamp -> "24 Aug 2026, 7:15 PM" */
function prettyStamp(iso) {
  const d = new Date(iso);
  if (isNaN(d)) return '-';
  return d.toLocaleString('en-IN', {
    day: 'numeric', month: 'short', year: 'numeric',
    hour: 'numeric', minute: '2-digit'
  });
}

/* 135 -> "2h 15m" */
function prettyDuration(mins) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return (h ? h + 'h ' : '') + m + 'm';
}

/* Today as "YYYY-MM-DD" (used to hide old shows and validate dates) */
function todayISO() {
  const d = new Date();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return d.getFullYear() + '-' + mm + '-' + dd;
}

/* Escape text before putting it inside innerHTML (keeps the page safe). */
function esc(text) {
  return String(text === undefined || text === null ? '' : text)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

/* Read a value from the page URL, e.g. seats.html?show=sh-12 */
function urlParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}
