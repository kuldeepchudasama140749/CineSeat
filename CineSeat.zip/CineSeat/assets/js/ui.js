/* ==========================================================================
   CineSeat  -  ui.js
   Small pieces of interface behaviour shared by every page:
   theme switch, mobile menu, toast messages, modal windows.
   ========================================================================== */

/* --------------------------------------------------------------------------
   1. LIGHT / DARK THEME
   -------------------------------------------------------------------------- */
function getTheme() {
  return localStorage.getItem('cs_theme') || 'light';
}

function setTheme(name) {
  localStorage.setItem('cs_theme', name);
  document.documentElement.setAttribute('data-theme', name);
}

function toggleTheme() {
  setTheme(getTheme() === 'dark' ? 'light' : 'dark');
}

/* --------------------------------------------------------------------------
   2. MOBILE MENU (the slide-in drawer on small screens)
   -------------------------------------------------------------------------- */
function initNav() {
  const burger   = document.getElementById('navBurger');
  const links    = document.getElementById('navLinks');
  const backdrop = document.getElementById('navBackdrop');

  /* The closed menu is display:none so it cannot make the page scroll
     sideways on a phone. To still get the sliding animation we first put it
     on the page (.is-mounted), wait one frame, and only then slide it in. */
  function openMenu() {
    if (!links) return;
    links.classList.add('is-mounted');
    requestAnimationFrame(function () {
      requestAnimationFrame(function () { links.classList.add('is-open'); });
    });
    if (backdrop) backdrop.classList.add('is-open');
  }

  function closeMenu() {
    if (links) {
      links.classList.remove('is-open');
      /* remove it from the page again once the slide-out has finished */
      setTimeout(function () { links.classList.remove('is-mounted'); }, 300);
    }
    if (backdrop) backdrop.classList.remove('is-open');
  }

  if (burger && links) {
    burger.addEventListener('click', function () {
      if (links.classList.contains('is-open')) closeMenu();
      else openMenu();
    });
    links.querySelectorAll('a').forEach(a => a.addEventListener('click', closeMenu));
  }
  if (backdrop) backdrop.addEventListener('click', closeMenu);

  /* Admin sidebar drawer (admin pages only) */
  const sideBtn  = document.getElementById('sideToggle');
  const sidebar  = document.getElementById('adminSidebar');
  if (sideBtn && sidebar) {
    sideBtn.addEventListener('click', function () {
      sidebar.classList.toggle('is-open');
      if (backdrop) backdrop.classList.toggle('is-open');
    });
    if (backdrop) backdrop.addEventListener('click', () => sidebar.classList.remove('is-open'));
  }

  /* Underline the link of the page we are currently on */
  const here = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('[data-nav]').forEach(a => {
    if (a.getAttribute('data-nav') === here) a.classList.add('is-active');
  });

  /* Theme button */
  const themeBtn = document.getElementById('themeToggle');
  if (themeBtn) themeBtn.addEventListener('click', toggleTheme);

  /* Esc closes menus and any open modal */
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    closeMenu();
    if (sidebar) sidebar.classList.remove('is-open');
    document.querySelectorAll('.modal.is-open').forEach(m => m.classList.remove('is-open'));
  });
}

/* --------------------------------------------------------------------------
   3. TOAST  -  small message box in the bottom corner
   -------------------------------------------------------------------------- */
function toast(message, type) {
  let box = document.getElementById('toastBox');
  if (!box) {
    box = document.createElement('div');
    box.id = 'toastBox';
    document.body.appendChild(box);
  }

  const icons = { success: '✅', error: '⛔', warn: '⚠️', info: '💡' };
  const kind  = type || 'info';

  const el = document.createElement('div');
  el.className = 'toast toast--' + kind;
  el.innerHTML = '<span>' + (icons[kind] || icons.info) + '</span><span>' + esc(message) + '</span>';
  box.appendChild(el);

  setTimeout(function () {
    el.classList.add('is-out');
    setTimeout(() => el.remove(), 320);
  }, 2800);
}

/* --------------------------------------------------------------------------
   4. MODAL WINDOWS
   -------------------------------------------------------------------------- */
function openModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.add('is-open');
}

function closeModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.remove('is-open');
}

/* Clicking the dark area or an element with data-close shuts the modal */
function initModals() {
  document.querySelectorAll('.modal').forEach(function (m) {
    m.addEventListener('click', function (e) {
      if (e.target === m || e.target.hasAttribute('data-close')) m.classList.remove('is-open');
    });
  });
}

/* A reusable "are you sure?" box, used before deleting anything */
function askConfirm(title, message, onYes) {
  let box = document.getElementById('confirmModal');

  if (!box) {
    box = document.createElement('div');
    box.className = 'modal';
    box.id = 'confirmModal';
    box.innerHTML =
      '<div class="modal__box" style="max-width:420px">' +
        '<div class="modal__head"><h3 id="cfTitle">Are you sure?</h3>' +
        '<button class="icon-btn icon-btn--sm" data-close aria-label="Close">✕</button></div>' +
        '<p id="cfText" class="text-muted"></p>' +
        '<div class="modal__foot">' +
          '<button class="btn btn--ghost" data-close>Cancel</button>' +
          '<button class="btn btn--danger" id="cfYes">Yes, continue</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(box);

    box.addEventListener('click', function (e) {
      if (e.target === box || e.target.hasAttribute('data-close')) box.classList.remove('is-open');
    });
  }

  box.querySelector('#cfTitle').textContent = title;
  box.querySelector('#cfText').textContent  = message;

  /* replace the button so old click handlers are removed */
  const yes = box.querySelector('#cfYes');
  const fresh = yes.cloneNode(true);
  yes.parentNode.replaceChild(fresh, yes);
  fresh.addEventListener('click', function () {
    box.classList.remove('is-open');
    onYes();
  });

  box.classList.add('is-open');
}

/* --------------------------------------------------------------------------
   5. START EVERYTHING when the page has loaded
   -------------------------------------------------------------------------- */
document.addEventListener('DOMContentLoaded', function () {
  initNav();
  initModals();
  if (typeof renderNavAuth === 'function') renderNavAuth();
});
