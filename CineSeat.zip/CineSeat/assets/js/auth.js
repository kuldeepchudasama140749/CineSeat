/* ==========================================================================
   CineSeat  -  auth.js
   Sign up, log in, log out and page protection for both the user side
   and the admin side. The logged-in person is kept in localStorage
   under the key "cs_session".
   ========================================================================== */

/* The one admin account of the cinema (demo project, so it is fixed here) */
const ADMIN_ACCOUNT = {
  name:     'Admin',
  email:    'admin@cineseat.com',
  password: 'Admin@123'
};

/* --------------------------------------------------------------------------
   Session helpers
   -------------------------------------------------------------------------- */
function getSession()   { return dbGet(KEYS.session, null); }
function setSession(s)  { dbSet(KEYS.session, s); }
function clearSession() { localStorage.removeItem(KEYS.session); }

function isLoggedIn() {
  const s = getSession();
  return !!(s && s.role === 'user');
}

function isAdmin() {
  const s = getSession();
  return !!(s && s.role === 'admin');
}

/* The full user record of whoever is logged in (or null) */
function currentUser() {
  const s = getSession();
  if (!s || s.role !== 'user') return null;
  return getUserById(s.userId);
}

/* --------------------------------------------------------------------------
   Register / login / logout
   -------------------------------------------------------------------------- */
function registerUser(name, email, phone, password) {
  if (findUserByEmail(email)) {
    return { ok: false, message: 'This email is already registered. Please log in.' };
  }
  const user = addUser({
    name: name.trim(),
    email: email.trim().toLowerCase(),
    phone: phone.trim(),
    password: password
  });
  setSession({ role: 'user', userId: user.id, name: user.name, email: user.email });
  return { ok: true, user: user };
}

function loginUser(email, password) {
  const user = findUserByEmail(email);
  if (!user)                    return { ok: false, message: 'No account found with this email.' };
  if (user.password !== password) return { ok: false, message: 'Wrong password. Please try again.' };
  if (user.blocked)             return { ok: false, message: 'This account has been blocked by the admin.' };

  setSession({ role: 'user', userId: user.id, name: user.name, email: user.email });
  return { ok: true, user: user };
}

function loginAdmin(email, password) {
  const okEmail = email.trim().toLowerCase() === ADMIN_ACCOUNT.email;
  const okPass  = password === ADMIN_ACCOUNT.password;
  if (!okEmail || !okPass) {
    return { ok: false, message: 'Invalid admin email or password.' };
  }
  setSession({ role: 'admin', name: ADMIN_ACCOUNT.name, email: ADMIN_ACCOUNT.email });
  return { ok: true };
}

function logout(goTo) {
  clearSession();
  window.location.href = goTo || 'index.html';
}

/* --------------------------------------------------------------------------
   Page guards
   -------------------------------------------------------------------------- */

/* Put this at the top of pages only a logged-in customer may open.
   It remembers where the person wanted to go, so login can send them back. */
function requireUser() {
  if (isLoggedIn()) return true;
  const back = window.location.pathname.split('/').pop() + window.location.search;
  window.location.href = 'login.html?next=' + encodeURIComponent(back);
  return false;
}

/* Put this at the top of every admin page except the admin login page. */
function requireAdmin() {
  if (isAdmin()) return true;
  window.location.href = 'login.html';
  return false;
}

/* --------------------------------------------------------------------------
   Navbar account area  (called automatically by ui.js)
   -------------------------------------------------------------------------- */
function renderNavAuth() {
  const box = document.getElementById('authArea');
  if (!box) return;

  const user = currentUser();

  if (!user) {
    box.innerHTML = '<a class="btn btn--primary btn--sm" href="login.html">Sign in</a>';
    return;
  }

  const initials = user.name.trim().split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();

  box.innerHTML =
    '<div class="account">' +
      '<button class="account__btn" id="accountBtn" aria-haspopup="true" aria-expanded="false">' +
        '<span class="account__avatar">' + esc(initials) + '</span>' +
        '<span class="account__name">' + esc(user.name.split(' ')[0]) + '</span>' +
      '</button>' +
      '<div class="account__menu" id="accountMenu">' +
        '<div class="account__head"><strong>' + esc(user.name) + '</strong>' +
        '<span class="text-xs text-muted">' + esc(user.email) + '</span></div>' +
        '<a href="my-bookings.html">🎟️ My Bookings</a>' +
        '<a href="movies.html">🍿 Browse Movies</a>' +
        '<button id="logoutBtn">↩︎ Log out</button>' +
      '</div>' +
    '</div>';

  const btn  = document.getElementById('accountBtn');
  const menu = document.getElementById('accountMenu');

  btn.addEventListener('click', function (e) {
    e.stopPropagation();
    const open = menu.classList.toggle('is-open');
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
  });

  document.addEventListener('click', function () { menu.classList.remove('is-open'); });

  document.getElementById('logoutBtn').addEventListener('click', function () {
    toast('You have been logged out', 'success');
    setTimeout(() => logout('index.html'), 600);
  });
}
